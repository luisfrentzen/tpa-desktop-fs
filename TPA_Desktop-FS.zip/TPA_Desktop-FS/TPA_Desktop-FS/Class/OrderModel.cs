﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class OrderModel
    {
        internal static void addOrder(Order newOrd)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Orders.Add(newOrd);
            db.SaveChanges();
        }

        public static int getLastIdx()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if (db.Orders.Any())
            {
                return db.Orders.Max(Order => Order.OrderId);
            }

            return 0;
        }

        internal static List<Order> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from order in db.Orders where order.IsCompleted == 0 orderby order.OrderId descending select order).ToList<Order>();
        }

        public static List<Order> getAllByTable(int tableId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from order in db.Orders where order.IsCompleted != 2 && order.TableId == tableId select order).ToList<Order>();
        }

        public static void deleteOrder(Order toEdit)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.SaveChanges();
        }

        public static void saveChanges()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.SaveChanges();
        }

        public static Order getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from order in db.Orders where order.OrderId == id && order.IsCompleted == 0 select order).FirstOrDefault();
        }

        public static void updateOrder(Order toEdit)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.SaveChanges();
        }

        public static Order getTableOrder(int id, int tableId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from order in db.Orders where order.OrderId == id && order.TableId == tableId && order.IsCompleted != 2 select order).FirstOrDefault();
        }
    }
}
