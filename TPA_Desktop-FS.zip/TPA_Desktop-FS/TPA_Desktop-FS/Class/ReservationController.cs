﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPA_Desktop_FS.View;

namespace TPA_Desktop_FS.Class
{
    class ReservationController
    {
        public static List<Reservation> getAll()
        {
            return ReservationModel.getAll();
        }

        public static void newReservation(string name, string idTxt, DateTime checkin, DateTime checkout, int roomId)
        {
            Reservation temp = new Reservation();
            temp.Id = ReservationModel.getLastId() + 1;
            temp.OccupantId = idTxt;
            temp.CheckInDate = checkin;
            temp.CheckOutDate = checkout;
            temp.Status = "Upcoming";
            temp.RoomId = roomId;

            ReservationModel.newReservation(temp);
        }

        public static bool checkReservation(int roomId, DateTime checkin, DateTime checkout)
        {
            List<Reservation> rsvList = getAllByRoom(roomId);
            foreach(Reservation r in rsvList)
            {
                if((DateTime.Compare((DateTime)r.CheckInDate, checkin) > 0 && DateTime.Compare((DateTime)r.CheckInDate, checkout) < 0))
                {
                    return false;
                }

                if ((DateTime.Compare((DateTime)r.CheckOutDate, checkin) > 0 && DateTime.Compare((DateTime)r.CheckOutDate, checkout) < 0))
                {
                    return false;
                }
            }

            return true;
        }

        public static List<Reservation> getAllByRoom(int roomId)
        {
            return ReservationModel.getAllByRoom(roomId);
        }

        public static void cancel(int id)
        {
            Reservation temp = getById(id);
            if(temp.Status == "Currently")
            {
                ErrorWindow r = new ErrorWindow("you cannot cancel an ongoing reservation");
                r.Show();
            }
            else
            {
                temp.Status = "Completed";
                DbEntities.saves();
            }
            
        }

        public static Reservation getById(int id)
        {
            return ReservationModel.getById(id);
        }

        public static void checkOut(int id)
        {
            

        }

        public static void checkIn(int id)
        {
            Reservation temp = getById(id);
            if(DateTime.Compare((DateTime)temp.CheckInDate, DateTime.Today) != 0)
            {
                ErrorWindow invalicheckin = new ErrorWindow("cannot check in");
                invalicheckin.Show();
            }
            else
            {
                int days = (temp.CheckOutDate.Value - temp.CheckInDate.Value).Days;
                int amount = days * 200000;

                PaymentWindow newPmt = new PaymentWindow(amount, null, "Hotel");
                newPmt.Show();
                Room room = RoomController.getById((int)temp.RoomId);
                room.RoomStatus = "Occupied";
                temp.Status = "Currently";
                room.OccupantId = temp.OccupantId;
                DbEntities.saves();
            }
        }

        public static Reservation getByCurrentRoom(int td)
        {
            return ReservationModel.getByCurrentRoom(td);
        }
    }
}
