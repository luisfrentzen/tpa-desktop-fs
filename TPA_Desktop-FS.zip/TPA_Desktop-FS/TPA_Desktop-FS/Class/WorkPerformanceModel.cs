﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class WorkPerformanceModel
    {
        public static void newWorkPerformance(WorkPerformance newWp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            newWp.IsDeleted = 0;
            db.WorkPerformances.Add(newWp);
            db.SaveChanges();
        }

        public static List<WorkPerformance> getAllByEmp(int empIdx)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            var result = (from workperformance in db.WorkPerformances where workperformance.EmpId == empIdx && workperformance.IsDeleted == 0 select new { workperformance.WpId, workperformance.ReportType, workperformance.Report });
            return result.AsEnumerable().Select(o => new WorkPerformance { WpId = o.WpId, ReportType = o.ReportType, Report = o.Report}).ToList<WorkPerformance>();

        }

        public static WorkPerformance getById(int repId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from workperformance in db.WorkPerformances where workperformance.WpId == repId && workperformance.IsDeleted == 0 select workperformance).FirstOrDefault();
        }

        public static void deleteWp(int wpId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            WorkPerformance toDel = getById(wpId);
            toDel.IsDeleted = 1;
            db.SaveChanges();
        }

        public static int getLastIndex()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.WorkPerformances.Any())
            {
                return db.WorkPerformances.Max(WorkPerformance => WorkPerformance.WpId);
            }

            return 0;
        }

        public static void updateWp(int wpId, string repType, string report)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            WorkPerformance toEdit = getById(wpId);
            toEdit.ReportType = repType;
            toEdit.Report = report;
            db.SaveChanges();
        }
    }
}
