﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class PlanSubmissionModel
    {
        public static int getLastIndex()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.PlanSubmissions.Any())
            {
                return db.PlanSubmissions.Max(PlanSubmission => PlanSubmission.Id);
            }

            return 0;
        }

        public static void newSubmission(PlanSubmission temp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.PlanSubmissions.Add(temp);
            db.SaveChanges();
        }

        public static List<PlanSubmission> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from plansubmission in db.PlanSubmissions where plansubmission.Status != "Completed" select plansubmission).ToList();
        }

        public static PlanSubmission getById(int id)
        { 
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from plansubmission in db.PlanSubmissions where plansubmission.Status != "Completed" && plansubmission.Id == id select plansubmission).FirstOrDefault();
        }

        public static PlanSubmission getPlanByAttride(AttractionRide ar)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from plansubmission in db.PlanSubmissions where plansubmission.Status != "Completed" && plansubmission.AttractionRideId == ar.id select plansubmission).FirstOrDefault();

        }

        public static List<PlanSubmission> getAllPlan()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from plansubmission in db.PlanSubmissions where (plansubmission.Status == "Waiting For Construction" || plansubmission.Status == "On Construction") && plansubmission.Status != "Completed" select plansubmission).ToList();

        }
    }
}
