﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class DismissModel
    {
        public static List<Dismiss> getByEmp(Employee emp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from raisedismiss in db.Dismisses where raisedismiss.Status != "Completed" && raisedismiss.EmpId == emp.EmployeeId select raisedismiss).ToList();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.Dismisses.Any())
            {
                return db.Dismisses.Max(rd => rd.Id);
            }

            return 0;
        }

        public static void newRequest(Dismiss rd)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Dismisses.Add(rd);
            db.SaveChanges();
        }
    }
}
