﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class AttractionRideModel
    {
        public static List<AttractionRide> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from attractionride in db.AttractionRides where attractionride.Status != "Removed" select attractionride).ToList();
        }

        public static List<AttractionRide> getAllReqMt()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from attractionride in db.AttractionRides where attractionride.Status != "Removed" && attractionride.Type == "Ride" orderby attractionride.Status select attractionride).ToList();
        }

        public static AttractionRide getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from attractionride in db.AttractionRides where attractionride.Status != "Removed" && attractionride.id == id select attractionride).FirstOrDefault();
        }
    }
}
