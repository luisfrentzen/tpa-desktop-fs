﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RequestController
    {
        public static List<Request> getAllByEmpByType(Employee user, string type)
        {
            return RequestModel.getAllByEmpByType(user, type);
        }

        public static void add(Employee user, string v, string detail)
        {
            Request temp = new Request();
            temp.Id = RequestModel.getLastId() + 1;
            temp.EmpId = user.EmployeeId;
            temp.Status = "Pending";
            temp.Type = v;
            temp.Details = detail;
            temp.Department = user.Department;

            RequestModel.add(temp);
        }


        public static List<Request> getAllByType(string v)
        {
            return RequestModel.getAllByType(v);
        }

        internal static Request getByIdByType(int id, string v)
        {
            return RequestModel.getByIdByType(id, v);
        }

        public static Request getByIdByEmp(int id, Employee user)
        {
            return RequestModel.getByIdByEmp(id, user);
        }

        public static Request getToPurchase(int id)
        {
            return RequestModel.getToPurchase(id);
        }
    }
}
