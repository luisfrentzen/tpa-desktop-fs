﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class HotelVisitorModel
    {
        public static HotelVisitor getById(string idTxt)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from visitor in db.HotelVisitors where visitor.Id == idTxt select visitor).FirstOrDefault();
        }

        public static void newVisitor(HotelVisitor temp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.HotelVisitors.Add(temp);
            db.SaveChanges();
        }
    }
}
