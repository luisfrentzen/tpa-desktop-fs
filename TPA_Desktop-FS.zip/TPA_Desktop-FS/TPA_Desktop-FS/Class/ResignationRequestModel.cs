﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class ResignationRequestModel
    {
        public static List<ResignationRequest> getAllByEmp(Employee user)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from resign in db.ResignationRequests where resign.EmpId == user.EmployeeId && resign.Status != "Completed" select resign).ToList();

        }

        public static int getLastIdx()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.ResignationRequests.Any())
            {
                return db.ResignationRequests.Max(r => r.Id);
            }

            return 0;
        }

        public static void addRequest(ResignationRequest temp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.ResignationRequests.Add(temp);
            db.SaveChanges();
        }
    }
}
