﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RaiseModel
    {
        public static List<Raise> getByEmp(Employee emp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from raisedismiss in db.Raises where raisedismiss.Status != "Completed" && raisedismiss.EmpId == emp.EmployeeId select raisedismiss).ToList();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if (db.Raises.Any())
            {
                return db.Raises.Max(rd => rd.Id);
            }

            return 0;
        }

        public static void newRequest(Raise rd)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Raises.Add(rd);
            db.SaveChanges();
        }
    }
}
