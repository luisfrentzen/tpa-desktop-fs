﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class MaintenanceController
    {
        public static List<MaintenanceSchedule> getAll()
        {
            return MaintenanceModel.getAll();
        }

        public static void addSchedule(AttractionRide ar, DateTime mt)
        {
            MaintenanceSchedule newmt = new MaintenanceSchedule();
            newmt.Id = MaintenanceModel.getLastId() + 1;
            newmt.AttractionRideId = ar.id;
            newmt.Status = "Upcoming";
            newmt.Time = mt;

            ar.Status = "On Maintenance";

            MaintenanceModel.addSchedule(newmt);
        }

        public static MaintenanceSchedule getByRide(AttractionRide ar)
        {
            return MaintenanceModel.getByRide(ar);
        }

        public static MaintenanceSchedule getById(int id)
        {
            return MaintenanceModel.getById(id);
        }
    }
}
