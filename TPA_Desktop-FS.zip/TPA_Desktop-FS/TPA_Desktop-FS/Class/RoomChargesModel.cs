﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RoomChargesModel
    {
        public static List<RoomCharge> getAllByRsv(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from charges in db.RoomCharges where charges.ReservationId == id && charges.Status != "Completed" select charges).ToList<RoomCharge>();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.RoomCharges.Any())
            {
                return db.RoomCharges.Max(RoomCharge => RoomCharge.Id); 
            }

            return 0;
        }

        public static void addCharges(RoomCharge rc)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.RoomCharges.Add(rc);
            db.SaveChanges();
        }
    }
}
