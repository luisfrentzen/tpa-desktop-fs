﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class MaintenanceReportController
    {
        public static void addReport(MaintenanceSchedule mtsched, string details)
        {
            MaintenanceReport p = new MaintenanceReport();
            p.Id = MaintenanceReportModel.getLastId() + 1;
            p.MaintenanceDetail = details;
            p.MaintenanceId = mtsched.Id;
            p.IsDeleted = 0;

            MaintenanceReportModel.addReport(p);
        }

        public static MaintenanceReport getByMt(MaintenanceSchedule mtsched)
        {
            return MaintenanceReportModel.getByMt(mtsched);
        }

        public static List<MaintenanceReport> getAll()
        {
            return MaintenanceReportModel.getAll();
        }

        public static MaintenanceReport getById(int id)
        {
            return MaintenanceReportModel.getById(id);
        }
    }
}
