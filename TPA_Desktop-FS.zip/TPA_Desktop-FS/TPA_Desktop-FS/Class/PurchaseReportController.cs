﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class PurchaseReportController
    {
        public static void addReport(int price, int id, DateTime date, Employee u)
        {
            PurchaseReport pr = new PurchaseReport();
            pr.Id = PurchaseReportModel.getLastId() + 1;
            pr.Price = price;
            pr.ReqId = id;
            pr.DateBought = date;
            pr.IsDeleted = 0;
            pr.EmpId = u.EmployeeId;

            PurchaseReportModel.addReport(pr);
        }

        public static void delete(PurchaseReport toEdit)
        {
            toEdit.IsDeleted = 1;
            DbEntities.saves();
        }

        public static void update()
        {
            DbEntities.saves();
        }

        public static List<PurchaseReport> getAll()
        {
            return PurchaseReportModel.getAll();
        }

        public static PurchaseReport getbyId(int id)
        {
            return PurchaseReportModel.getByid(id);
        }

        public static PurchaseReport getbyReqId(int id)
        {
            return PurchaseReportModel.getbyReqId(id);
        }
    }
}
