﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class MaintenanceModel
    {
        public static List<MaintenanceSchedule> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from maintenance in db.MaintenanceSchedules where maintenance.Status != "Completed" select maintenance).ToList();
        }

        public static void addSchedule(MaintenanceSchedule newmt)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.MaintenanceSchedules.Add(newmt);
            db.SaveChanges();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.MaintenanceSchedules.Any())
            {
                return db.MaintenanceSchedules.Max(MaintenanceSchedule => MaintenanceSchedule.Id);
            }

            return 0;
        }

        public static MaintenanceSchedule getByRide(AttractionRide ar)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from maintenance in db.MaintenanceSchedules where maintenance.Status != "Completed" && maintenance.Status != "Done" && maintenance.AttractionRideId == ar.id select maintenance).FirstOrDefault();

        }

        public static MaintenanceSchedule getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from maintenance in db.MaintenanceSchedules where maintenance.Status != "Completed" && maintenance.Id == id select maintenance).FirstOrDefault();
        }
    }
}
