﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace TPA_Desktop_FS.Class
{
    class RoomChargesController
    {
        public static List<RoomCharge> getAllByRsv(int id)
        {
            return RoomChargesModel.getAllByRsv(id);
        }

        public static int getTotal(int id)
        {
            int total = 0;
            List<RoomCharge> rList = getAllByRsv(id);
            foreach(RoomCharge r in rList)
            {
                total = total + (int)r.Price;
            }

            return total;
        }

        public static void completeAllById(List<RoomCharge> r)
        {
            foreach(RoomCharge rc in r)
            {
                rc.Status = "Completed";
            }

            ReservationModel.saveChanges();
        }

        public static void addCharges(Reservation rv, string item, int price)
        {
            RoomCharge rc = new RoomCharge();
            rc.Name = item;
            rc.Price = price;
            rc.Status = "Current";
            rc.ReservationId = rv.Id;
            rc.Id = RoomChargesModel.getLastId() + 1;

            RoomChargesModel.addCharges(rc);
        }

        public static void delete(RoomCharge rc)
        {
            rc.Status = "Completed";
            DbEntities.saves();
        }

        public static RoomCharge getByIdByRsv(int id1, int id2)
        {
            List<RoomCharge> rList = getAllByRsv(id1);

            foreach(RoomCharge rcharge in rList)
            {
                if(rcharge.Id == id2)
                {
                    return rcharge;
                }
            }

            return null;
        }

        public static void updateCharges(RoomCharge rc, string item, int price)
        {
            rc.Name = item;
            rc.Price = price;

            DbEntities.saves();
        }
    }
}
