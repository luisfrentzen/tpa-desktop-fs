﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class TransactionModel
    {
        public static void newTransaction(Transaction newTr)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Transactions.Add(newTr);
            db.SaveChanges();
        }

        public static Transaction getById(int id, string type)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from transactions in db.Transactions where transactions.TrId == id && transactions.TrType == type && transactions.IsDeleted == 0 select transactions).FirstOrDefault();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if (db.Transactions.Any())
            {
                return db.Transactions.Max(Transaction => Transaction.TrId);
            }

            return 0;
        }

        public static void updateTransaction(int trId, int amount)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            Transaction toEdit = (from transaction in db.Transactions where transaction.TrId == trId select transaction).FirstOrDefault();
            toEdit.TrAmount = amount;
            db.SaveChanges();
        }

        public static void deteleTransaction(Transaction toEdit)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            toEdit.IsDeleted = 1;
            db.SaveChanges();
        }

        public static List<Transaction> getAllByDept(string v)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            var result = (from transaction in db.Transactions where transaction.TrType == v && transaction.IsDeleted == 0 orderby transaction.TrId descending select new { transaction.TrId, transaction.TrType, transaction.TrAmount, transaction.TrDate });
            return result.AsEnumerable().Select(o => new Transaction { TrId = o.TrId, TrDate = o.TrDate, TrType = o.TrType, TrAmount = o.TrAmount }).ToList<Transaction>();
        }
    }
}
