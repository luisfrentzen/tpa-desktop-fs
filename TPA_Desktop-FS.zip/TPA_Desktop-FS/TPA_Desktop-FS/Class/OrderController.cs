﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class OrderController
    {
        public static void addOrder(string menu, int id, int ordPrice, string ordType, int qty)
        {
            Order newOrd = new Order();
            newOrd.MenuName = menu;
            newOrd.OrderId = OrderModel.getLastIdx() + 1;
            newOrd.TableId = id;
            newOrd.Price = ordPrice;
            newOrd.OrderType = ordType;
            newOrd.IsCompleted = 0;
            newOrd.Qty = qty;
            newOrd.Total = qty * ordPrice;

            OrderModel.addOrder(newOrd);
            TableController.updateTable(id, "Add");
        }

        public static List<Order> getAll()
        {
            return OrderModel.getAll();
        }

        public static List<Order> getAllByTable(int tableId)
        {
            return OrderModel.getAllByTable(tableId);
        }

        public static Order getTableOder(int id, int tableId)
        {
            return OrderModel.getTableOrder(id, tableId);
        }

        public static void deleteOrder(Order toEdit)
        {
            toEdit.IsCompleted = 2;
            OrderModel.saveChanges();
        }

        public static void updateOrder(Order toEdit)
        {
            toEdit.Total = toEdit.Qty * toEdit.Price;
            OrderModel.saveChanges();
        }

        public static Order getById(int id)
        {
            return OrderModel.getById(id);
        }
    }
}
