﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class FeedbackController
    {
        public static void newFeedback(int trId, string rating, string feedback, string type)
        {
            int id = FeedbackModel.getLastId();
            Feedback newfb = new Feedback();
            newfb.Id = id + 1;
            newfb.TrId = trId;
            newfb.Rating = rating;
            newfb.Feedback1 = feedback;
            newfb.Type = type;

            FeedbackModel.newFeedback(newfb);
        }


        public static List<Feedback> getAllByDept(string dept)
        {
            return FeedbackModel.getAllByDept(dept);
        }
    }
}
