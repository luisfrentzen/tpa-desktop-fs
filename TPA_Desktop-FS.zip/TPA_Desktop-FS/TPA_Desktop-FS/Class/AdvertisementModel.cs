﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class AdvertisementModel
    {
        public static List<Advertisement> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from advertisement in db.Advertisements where advertisement.IsDeleted == 0 select advertisement).ToList<Advertisement>();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if (db.Advertisements.Any())
            {
                return db.Advertisements.Max(Advertisement => Advertisement.AdId);
            }

            return 0;
        }

        public static void AddAd(Advertisement newAd)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            newAd.IsDeleted = 0;
            db.Advertisements.Add(newAd);
            db.SaveChanges();
        }

        public static void updateAd(int adId, string name, string type)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            Advertisement edit = getById(adId);
            edit.AdName = name;
            edit.AdType = type;

            db.SaveChanges();
        }

        public static Advertisement getById(int adId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from advertisement in db.Advertisements where advertisement.AdId == adId && advertisement.IsDeleted == 0 select advertisement).FirstOrDefault();
        }

        public static void deleteAd(int adId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            Advertisement toDel = getById(adId);
            toDel.IsDeleted = 1;
            db.SaveChanges();
        }
    }
}
