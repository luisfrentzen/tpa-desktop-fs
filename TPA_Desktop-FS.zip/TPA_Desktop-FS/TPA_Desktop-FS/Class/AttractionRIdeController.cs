﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class AttractionRideController
    {
        public static List<AttractionRide> getAll()
        {
            return AttractionRideModel.getAll();
        }

        public static AttractionRide getById(int id)
        {
            return AttractionRideModel.getById(id);
        }


        internal static List<AttractionRide> getAllReqMt()
        {
            return AttractionRideModel.getAllReqMt();
        }
    }
}
