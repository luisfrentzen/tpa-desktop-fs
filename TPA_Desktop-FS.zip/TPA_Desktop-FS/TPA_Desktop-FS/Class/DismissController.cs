﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class DismissController
    {
        public static List<Dismiss> getByEmp(Employee emp)
        {
            return DismissModel.getByEmp(emp);
        }

        public static void newRequest(Employee emp, string reason)
        {
            Dismiss rd = new Dismiss();
            rd.Id = DismissModel.getLastId() + 1; 
            rd.EmpId = emp.EmployeeId;
            rd.Reason = reason;
            rd.Status = "Pending";

            DismissModel.newRequest(rd);
        }

    }
}
