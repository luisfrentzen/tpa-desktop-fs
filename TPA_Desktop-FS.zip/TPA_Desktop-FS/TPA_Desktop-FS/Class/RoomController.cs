﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RoomController
    {
        public static List<Room> getAll()
        {
            return RoomModel.getAll();
        }

        public static Room getById(int roomId)
        {
            return RoomModel.getById(roomId);
        }
    }
}
