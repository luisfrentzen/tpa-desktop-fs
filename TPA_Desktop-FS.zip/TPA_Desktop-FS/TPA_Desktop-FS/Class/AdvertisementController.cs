﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class AdvertisementController
    {
        public static List<Advertisement> getAll()
        {
            return AdvertisementModel.getAll();
        }

        public static void newAdd(string name, string type)
        {
            int id = AdvertisementModel.getLastId();
            Advertisement newAd = new Advertisement();
            newAd.AdId = id+1;
            newAd.AdName = name;
            newAd.AdType = type;

            AdvertisementModel.AddAd(newAd);
        }

        public static Advertisement getById(int adId)
        {
            return AdvertisementModel.getById(adId);
        }

        public static void updateAd(int adId, string name, string type)
        {
            AdvertisementModel.updateAd(adId, name, type);
        }

        public static void deleteAd(int adId)
        {
            AdvertisementModel.deleteAd(adId);
        }
    }
}
