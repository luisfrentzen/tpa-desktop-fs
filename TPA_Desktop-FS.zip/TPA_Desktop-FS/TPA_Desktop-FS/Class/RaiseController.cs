﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RaiseController
    {
        public static List<Raise> getByEmp(Employee emp)
        {
            return RaiseModel.getByEmp(emp);
        }

        public static void newRequest(Employee emp, int raiseto, string reason)
        {
            Raise rd = new Raise();
            rd.Id = RaiseModel.getLastId() + 1;
            rd.EmpId = emp.EmployeeId;
            rd.RaiseTo = raiseto;
            rd.Reason = reason;
            rd.Status = "Pending";

            RaiseModel.newRequest(rd);
        }
    }
}
