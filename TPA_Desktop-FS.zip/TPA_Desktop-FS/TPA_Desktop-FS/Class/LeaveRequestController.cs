﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class LeaveRequestController
    {
        public static void newRequest(Employee user, DateTime sDate, int daycount, string reason)
        {
            LeaveRequest temp = new LeaveRequest();
            temp.Id = LeaveRequestModel.getLastId() + 1;
            temp.StartDate = sDate;
            temp.Status = "Pending";
            temp.DayCount = daycount;
            temp.Details = reason;
            temp.EmpId = user.EmployeeId;

            LeaveRequestModel.newRequest(temp);
        }

        public static List<LeaveRequest> getAllByEmp(Employee user)
        {
            return LeaveRequestModel.getAllByEmp(user);
        }

        public static List<LeaveRequest> getAll()
        {
            return LeaveRequestModel.getAll();
        }

        public static LeaveRequest getById(int id)
        {
            return LeaveRequestModel.getById(id);
        }
    }
}
