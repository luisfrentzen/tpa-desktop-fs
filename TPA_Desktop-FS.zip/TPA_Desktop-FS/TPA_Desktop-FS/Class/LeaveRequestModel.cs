﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class LeaveRequestModel
    {
        public static void newRequest(LeaveRequest temp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.LeaveRequests.Add(temp);
            db.SaveChanges();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.LeaveRequests.Any())
            {
                return db.LeaveRequests.Max(l => l.Id);

            }
            return 0;

        }

        public static List<LeaveRequest> getAllByEmp(Employee user)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from leave in db.LeaveRequests where leave.EmpId == user.EmployeeId && leave.Status != "Completed" select leave).ToList();
        }

        public static List<LeaveRequest> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from leave in db.LeaveRequests where leave.Status != "Completed" select leave).ToList();

        }

        public static LeaveRequest getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from leave in db.LeaveRequests where leave.Id == id && leave.Status != "Completed" select leave).FirstOrDefault();

        }
    }
}
