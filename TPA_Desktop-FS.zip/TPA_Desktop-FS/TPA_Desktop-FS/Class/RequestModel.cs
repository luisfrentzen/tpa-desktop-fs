﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RequestModel
    {
        public static List<Request> getAllByEmpByType(Employee user, string type)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from request in db.Requests where request.EmpId == user.EmployeeId && request.Status != "Completed" && request.Type == type select request).ToList<Request>();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();

            if(db.Requests.Any())
            {
                return db.Requests.Max(Request => Request.Id);
            }

            return 0;
        }

        public static void add(Request temp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Requests.Add(temp);
            db.SaveChanges();
        }

        public static Request getByIdByType(int id, string v)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from request in db.Requests where request.Id == id && request.Status == "Pending" && request.Type == v select request).FirstOrDefault();
        }

        public static Request getToPurchase(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from request in db.Requests where request.Id == id && request.Status != "Completed" && request.Type == "Purchase" select request).FirstOrDefault();
        }

        public static Request getByIdByEmp(int id, Employee user)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from request in db.Requests where request.Status != "Completed" && request.Id == id && request.EmpId == user.EmployeeId select request).FirstOrDefault();
        }

        public static List<Request> getAllByType(string v)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from request in db.Requests where request.Status != "Completed" && request.Type == v select request).ToList<Request>();

        }
    }
}
