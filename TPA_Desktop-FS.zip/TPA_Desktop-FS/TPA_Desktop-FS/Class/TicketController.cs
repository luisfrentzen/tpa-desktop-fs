﻿using Gma.QrCodeNet.Encoding;
using Gma.QrCodeNet.Encoding.Windows.Render;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace TPA_Desktop_FS.Class
{
    class TicketController
    {
        public static Ticket newTicket()
        {
            DateTime currentDate = DateTime.Today;
            String validDate = currentDate.ToString("ddMMyy");
            String id = generateId(validDate);

            Ticket temp = new Ticket();
            temp.TicketDate = validDate;
            temp.TicketId = id;
            temp.TicketStatus = "New";

            TicketModel.newTicket(temp);
            return temp;

        }

        public static WriteableBitmap generateQr(Ticket temp)
        {
            QrEncoder encoder = new QrEncoder(ErrorCorrectionLevel.M);
            QrCode qrCode;
            encoder.TryEncode(temp.TicketId, out qrCode);
            WriteableBitmapRenderer wRenderer = new WriteableBitmapRenderer(new FixedModuleSize(2, QuietZoneModules.Two), Colors.Black, Colors.White);
            WriteableBitmap wBitmap = new WriteableBitmap(50, 50, 400, 400, PixelFormats.Gray8, null);
            wRenderer.Draw(wBitmap, qrCode.Matrix);

            return wBitmap;
        }

        public static String generateId(String currentDate)
        {
            String id;
            Ticket newDateId = TicketModel.findDate(currentDate);
            if(newDateId == null)
            {
                id = currentDate + "000001";
            }
            else
            {
                int idx = (int.Parse(newDateId.TicketId.Substring(5)) + 1);
                id = currentDate;
                int digitCount = idx.ToString().Length;
                for (int a = 0; a < 6 - digitCount; a++)
                {
                    id += '0';
                }
                id += idx;
            }
            return id;
        }

        public static List<ParkInfo> getParkInfo()
        {
            return TicketModel.getAllParkInfo();
        }

        public static int validateTicket(String ticketId)
        {
            DateTime currentDate = DateTime.Today;
            String validDate = currentDate.ToString("ddMMyy");

            if( ticketId.Substring(0, 6) != validDate)
            {
                return -1;
            }

            Ticket temp = TicketModel.findId(ticketId);

            if(temp == null)
            {
                return 1;
            }
            else if(temp.TicketStatus == "Activated")
            {
                return 2;
            }

            TicketModel.updateTicketStatus(ticketId);
            return 0;
        }

        public static Ticket getById(string ticketId)
        {
            return TicketModel.getById(ticketId);
        }

        public static void deactivateTicket(Ticket toDel)
        {
            TicketModel.deactivate(toDel);
        }
    }
}
