﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPA_Desktop_FS.View;

namespace TPA_Desktop_FS.Class
{
    class TableController
    {
        public static List<Table> getAll()
        {
            return TableModel.getAll();
        }

        public static Table getById(int id)
        {
            return TableModel.getById(id);
        }

        public static Table newTakeAway(int id)
        {
            Table tb = new Table();
            tb.TableId = id;
            tb.Type = "Take Away";
            tb.TableStatus = "Preparing Order";

            TableModel.newTakeAway(tb);
            return tb;
        }

        public static void updateTable(int id, string v)
        {
            Table tb = TableModel.getById(id);
            if( v == "Add")
            {
                if(tb.TableStatus == "Free" || tb.TableStatus == "Completed")
                {
                    tb.TableStatus = "Preparing Order";
                }
            }
            else if( v == "Del")
            {

            }

            TableModel.updateTable();
        }

        public static int getTotal(Table tbPayment)
        {
            List<Order> ordList = OrderController.getAllByTable(tbPayment.TableId);
            int total = 0;
            foreach (Order o in ordList)
            {
                total = total + (int)o.Total;
            }

            return total;
        }

        public static void cancelTable(int tableId)
        {
            Table tocancel = TableModel.getById(tableId);
            List<Order> tableOrder = OrderController.getAllByTable(tocancel.TableId);
            foreach (Order o in tableOrder)
            {
                OrderController.deleteOrder(o);
            }

            if (tocancel.Type == "Dine In")
            {
                tocancel.TableStatus = "Free";
            }
            else
            {
                tocancel.TableStatus = "Completed";
            }

            TableModel.updateTable();
        }
    }
}
