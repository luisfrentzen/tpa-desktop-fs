﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class TableModel
    {
        public static List<Table> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from table in db.Tables where table.TableStatus != "Completed" select table).ToList<Table>();
        }

        public static Table getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from table in db.Tables where table.TableId == id select table).FirstOrDefault();
        }

        internal static void newTakeAway(Table tb)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Tables.Add(tb);
            db.SaveChanges();
        }

        public static void updateTable()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.SaveChanges();
        }

    }
}
