﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class TransactionController
    {
        public static Transaction newTransaction(int amt, string type)
        {
            Transaction newTr = new Transaction();
            newTr.TrDate = DateTime.Today;
            newTr.TrAmount = amt;
            newTr.IsDeleted = 0;
            newTr.TrType = type;
            newTr.TrId = TransactionModel.getLastId() + 1;
            
            TransactionModel.newTransaction(newTr);
            return newTr;
        }

        public static Transaction getById(int id, string type)
        {
            return TransactionModel.getById(id, type);
        }

        public static void updateTransaction(int trId, int amount)
        {
            TransactionModel.updateTransaction(trId, amount);
        }

        public static void deleteTransaction(Transaction toEdit)
        {
            TransactionModel.deteleTransaction(toEdit);
        }

        public static List<Transaction> getAllByDept(string v)
        {
            return TransactionModel.getAllByDept(v);
        }
    }
}
