﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class HotelVisitorController
    {
        public static HotelVisitor getById(string idTxt)
        {
            return HotelVisitorModel.getById(idTxt);
        }

        public static void newVisitor(string name, string idTxt)
        {
            HotelVisitor temp = new HotelVisitor();
            temp.Name = name;
            temp.Id = idTxt;

            HotelVisitorModel.newVisitor(temp);
        }
    }
}
