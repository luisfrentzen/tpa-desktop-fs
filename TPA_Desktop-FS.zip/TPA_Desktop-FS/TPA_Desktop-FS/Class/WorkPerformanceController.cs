﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class WorkPerformanceController
    {
        public static void newWorkPerformance(int empIdx, string reportType, string report)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            WorkPerformance newWp = new WorkPerformance();
            int index = WorkPerformanceModel.getLastIndex();

            newWp.WpId = index + 1;

            newWp.EmpId = empIdx;
            newWp.ReportType = reportType;
            newWp.Report = report;

            WorkPerformanceModel.newWorkPerformance(newWp);
        }

        public static WorkPerformance getById(int repId)
        {
            return WorkPerformanceModel.getById(repId);
        }

        public static List<WorkPerformance> getEmployeeWp(int empIdx)
        {
            return WorkPerformanceModel.getAllByEmp(empIdx);
        }

        public static void deleteWp(int wpId)
        {
            WorkPerformanceModel.deleteWp(wpId);
        }

        public static void updateWp(int wpId, string repType, string report)
        {
            WorkPerformanceModel.updateWp(wpId, repType, report);
        }
    }
}
