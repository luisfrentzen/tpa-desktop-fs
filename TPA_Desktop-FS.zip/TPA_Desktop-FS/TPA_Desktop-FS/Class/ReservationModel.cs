﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class ReservationModel
    {
        public static List<Reservation> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from reservation in db.Reservations where reservation.Status != "Completed" select reservation).ToList<Reservation>();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if (db.Reservations.Any())
            {
                return db.Reservations.Max(Reservation => Reservation.Id);
            }

            return 0;
        }

        public static void newReservation(Reservation temp)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Reservations.Add(temp);
            db.SaveChanges();
        }

        public static List<Reservation> getAllByRoom(int roomId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from reservation in db.Reservations where reservation.RoomId == roomId && reservation.Status != "Completed" select reservation).ToList<Reservation>();
        }

        public static Reservation getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from reservation in db.Reservations where reservation.Id == id && reservation.Status != "Completed" select reservation).FirstOrDefault();

        }

        public static void saveChanges()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.SaveChanges();
        }

        public static Reservation getByCurrentRoom(int td)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from reservation in db.Reservations where reservation.RoomId == td && reservation.Status != "Completed" && reservation.Status != "Upcoming" select reservation).FirstOrDefault();
        }
    }
}
