﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class MaintenanceReportModel
    {
        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.MaintenanceReports.Any())
            {
                return db.MaintenanceReports.Max(mt => mt.Id);
            }

            return 0;
        }

        public static void addReport(MaintenanceReport p)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.MaintenanceReports.Add(p);
            db.SaveChanges();
        }

        public static MaintenanceReport getByMt(MaintenanceSchedule mtsched)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from report in db.MaintenanceReports where report.MaintenanceId == mtsched.Id select report).FirstOrDefault();
        }

        public static MaintenanceReport getById(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from report in db.MaintenanceReports where report.IsDeleted == 0 && report.Id == id select report).FirstOrDefault();
        }

        public static List<MaintenanceReport> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from report in db.MaintenanceReports where report.IsDeleted == 0 select report).ToList();
        }
    }
}
