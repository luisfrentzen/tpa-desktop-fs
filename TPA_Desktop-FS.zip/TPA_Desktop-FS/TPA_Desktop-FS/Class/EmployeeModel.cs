﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class EmployeeModel
    {
        private String name;
        private String username;
        private String password;
        private String department;
        private int salary;
        private int employeeId;
        private String status;

        public static void newEmployee(Employee newEmployee)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            int index = db.Employees.Max(Employee => Employee.EmployeeId);
            newEmployee.EmployeeId = index + 1;
 
            db.Employees.Add(newEmployee);
            db.SaveChanges();
        }

        public static Employee getByName(String name)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            Employee data = (from employee in db.Employees where employee.Name.ToLower() == name.ToLower() select employee).FirstOrDefault();
            return data;
        }

        public static Employee login(String username, String password)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            return (from employee in db.Employees where employee.Username == username && employee.Password == password select employee).FirstOrDefault();
        }
    }
}
