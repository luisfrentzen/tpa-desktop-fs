﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace TPA_Desktop_FS.Class
{

    class TicketModel
    {
        String ticketId;
        String validDate;
        WriteableBitmap qrCode;

        public static void newTicket(Ticket newTicket)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            db.Tickets.Add(newTicket);
            db.SaveChanges();
        }

        public static Ticket findId(String ticketid)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            Ticket validId = (from ticket in db.Tickets where ticket.TicketId == ticketid select ticket).FirstOrDefault();
            return validId;
        }

        public static Ticket findDate(string currentDate)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            Ticket validId = (from ticket in db.Tickets orderby ticket.TicketId descending select ticket).FirstOrDefault();
            return validId;
      
        }

        public static void updateTicketStatus(String ticketId)
        {
            UnderTheSeaEntities db = new UnderTheSeaEntities();
            db.Configuration.ProxyCreationEnabled = false;
            Ticket temp = (from ticket in db.Tickets where ticket.TicketId == ticketId select ticket).FirstOrDefault();
            temp.TicketStatus = "Activated";
            DateTime currentDate = DateTime.Today;
            string validDate = currentDate.ToString("ddMMyy");
            ParkInfo pInfo = (from info in db.ParkInfoes where info.Date == validDate select info).FirstOrDefault();
            if(pInfo == null)
            {
                ParkInfo newEntry = new ParkInfo();
                newEntry.Date = validDate;
                newEntry.VisitorCount = 1;
                db.ParkInfoes.Add(newEntry);
            }
            else
            {
                pInfo.VisitorCount += 1;
            }
            db.SaveChanges();
        }

    }
}
