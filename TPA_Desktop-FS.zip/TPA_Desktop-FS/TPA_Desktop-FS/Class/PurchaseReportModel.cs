﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class PurchaseReportModel
    {
        public static void addReport(PurchaseReport pr)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.PurchaseReports.Add(pr);
            db.SaveChanges();
        }

        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if(db.PurchaseReports.Any())
            {
                return db.PurchaseReports.Max(PurchaseReport => PurchaseReport.Id);
            }

            return 0;
        }

        public static List<PurchaseReport> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from purchasereport in db.PurchaseReports where purchasereport.IsDeleted == 0 select purchasereport).ToList<PurchaseReport>();
        }

        public static PurchaseReport getByid(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from purchasereport in db.PurchaseReports where purchasereport.IsDeleted == 0 && purchasereport.Id == id select purchasereport).FirstOrDefault();
        }

        public static PurchaseReport getbyReqId(int id)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from purchasereport in db.PurchaseReports where purchasereport.IsDeleted == 0 && purchasereport.ReqId == id select purchasereport).FirstOrDefault();

        }
    }
}
