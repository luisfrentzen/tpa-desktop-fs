﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class EmployeeController
    {
        public static void newEmployee(String name, String username, String password, String department, int salary)
        {
            Employee newEmp = new Employee();
            newEmp.Name = name;
            newEmp.Username = username;
            newEmp.Password = password;
            newEmp.Department = department;
            newEmp.Salary = salary;
            newEmp.Status = "Active";
            EmployeeModel.newEmployee(newEmp);
        }

        public static void updateEmployeeSalary(int employeeId, int salary)
        {

        }

        public static void deleteEmployee(int employeeId)
        {

        }

        public static Employee getByName(String empName)
        {
            return EmployeeModel.getByName(empName);
        }

        public static Employee userLogin(String uname, String pwd)
        {
            return EmployeeModel.login(uname, pwd);
        }
    }

    
}
