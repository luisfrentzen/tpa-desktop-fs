﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class DbEntities
    {
        private static UnderTheSeaEntities db;

        private DbEntities()
        {

        }

        public static void saves()
        {
            getEntityModel().SaveChanges();
        }
        public static UnderTheSeaEntities getEntityModel()
        {
            if(db == null)
            {
                db = new UnderTheSeaEntities();
                db.Configuration.ProxyCreationEnabled = false;
            }

            return db;
        }
    }
}
