﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class ResignationRequestController
    {
        public static List<ResignationRequest> getAllByEmp(Employee user)
        {
            return ResignationRequestModel.getAllByEmp(user);
        }

        public static void addRequest(Employee user, string reason, DateTime sDate)
        {
            ResignationRequest temp = new ResignationRequest();
            temp.Id = ResignationRequestModel.getLastIdx() + 1;
            temp.Details = reason;
            temp.Status = "Pending";
            temp.EmpId = user.EmployeeId;
            temp.ResignationDate = sDate;

            ResignationRequestModel.addRequest(temp);
        }

        internal static List<ResignationRequest> getAll()
        {
            throw new NotImplementedException();
        }
    }
}
