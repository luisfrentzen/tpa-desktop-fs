﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class RoomModel
    {
        public static List<Room> getAll()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from room in db.Rooms select room).ToList<Room>();
        }

        public static Room getById(int roomId)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from room in db.Rooms where room.Id == roomId select room).FirstOrDefault();
        }
    }
}
