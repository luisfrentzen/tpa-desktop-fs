﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class FeedbackModel
    {
        public static int getLastId()
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            if (db.Feedbacks.Any())
            {
                return db.Feedbacks.Max(Feedback => Feedback.Id);
            }

            return 0;
        }

        public static void newFeedback(Feedback newfb)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            db.Feedbacks.Add(newfb);
            db.SaveChanges();
        }

        public static List<Feedback> getAllByDept(string dept)
        {
            UnderTheSeaEntities db = DbEntities.getEntityModel();
            return (from feedback in db.Feedbacks where feedback.Type == dept select feedback).ToList<Feedback>();
        }
    }
}
