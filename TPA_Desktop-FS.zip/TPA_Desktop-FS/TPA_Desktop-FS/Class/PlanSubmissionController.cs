﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPA_Desktop_FS.Class
{
    class PlanSubmissionController
    {
        public static void newSubmission(string name, string details, string desc, string type, string subtype)
        {
            PlanSubmission temp = new PlanSubmission();
            temp.Name = name;
            temp.Description = desc;
            temp.PlanDetails = details;
            temp.Type = type;
            temp.Status = "Pending";
            temp.SubmissionType = subtype;
            temp.Id = PlanSubmissionModel.getLastIndex() + 1;
            PlanSubmissionModel.newSubmission(temp);
        }

        public static List<PlanSubmission> getAll()
        {
            return PlanSubmissionModel.getAll();
        }

        public static PlanSubmission getById(int id)
        {
            return PlanSubmissionModel.getById(id);
        }


        public static void updateAttractionRide(AttractionRide ar, string name, string details)
        {
            PlanSubmission temp = new PlanSubmission();
            temp.Name = name;
            temp.AttractionRideId = ar.id;
            temp.PlanDetails = details;
            temp.Type = ar.Type;
            temp.Status = "Pending";
            temp.SubmissionType = "Update";
            temp.Id = PlanSubmissionModel.getLastIndex() + 1;
            PlanSubmissionModel.newSubmission(temp);
        }

        public static PlanSubmission getPlanByAttride(AttractionRide ar)
        {
            return PlanSubmissionModel.getPlanByAttride(ar);
        }

        public static void removeAttractionRide(AttractionRide ar)
        {
            PlanSubmission temp = new PlanSubmission();
            temp.Name = ar.Name;
            temp.AttractionRideId = ar.id;
            temp.PlanDetails = ar.Details;
            temp.Type = ar.Type;
            temp.Status = "Pending";
            temp.SubmissionType = "Remove";
            temp.Id = PlanSubmissionModel.getLastIndex() + 1;
            PlanSubmissionModel.newSubmission(temp);
        }

        public static List<PlanSubmission> getAllPlan()
        {
            return PlanSubmissionModel.getAllPlan();
        }
    }
}
