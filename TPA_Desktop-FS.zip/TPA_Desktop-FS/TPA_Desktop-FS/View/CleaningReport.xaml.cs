﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for CleaningReport.xaml
    /// </summary>
    public partial class CleaningReport : Window
    {
        Reservation r;
        Dashboard w;
        public CleaningReport(Reservation tocharge, Dashboard dWindow)
        {
            InitializeComponent();
            r = tocharge;
            w = dWindow;

            room.Text = r.RoomId.ToString();

            populateCgGd();
        }

        public void populateCgGd()
        {
            List<RoomCharge> data = RoomChargesController.getAllByRsv(r.Id);
            dgCharges.IsReadOnly = true;
            dgCharges.CanUserResizeColumns = false;
            dgCharges.CanUserResizeRows = false;
            dgCharges.CanUserSortColumns = false;
            dgCharges.CanUserDeleteRows = false;
            dgCharges.CanUserAddRows = false;
            dgCharges.ItemsSource = data;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            w.populateRsvGd2();
        }

        private void chargeAdd_Click(object sender, RoutedEventArgs e)
        {
            string item = chargename.Text;
            string pricetxt = chargeprice.Text;
            int price;

            chargename.Text = "";
            chargeprice.Text = "";

            if(item == "" || pricetxt == "")
            {
                ErrorWindow er = new ErrorWindow("please fill necessary field(s)");
                er.Show();
            }
            else
            {
                if(!int.TryParse(pricetxt, out price))
                {
                    ErrorWindow er = new ErrorWindow("price must be a number");
                    er.Show();
                }
                else
                {
                    RoomChargesController.addCharges(r, item, price);
                    populateCgGd();
                }
            }
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            string idtxt = searchCgId.Text;
            int id;
            searchCgId.Text = "";

            if(idtxt == "")
            {
                ErrorWindow er = new ErrorWindow("please fill necessary field(s)");
                er.Show();
            }
            else
            {
                if(!int.TryParse(idtxt, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    RoomCharge toEdit = RoomChargesController.getByIdByRsv(r.Id ,id);
                    if(toEdit == null)
                    {
                        ErrorWindow er = new ErrorWindow("item not found");
                        er.Show();
                    }
                    else
                    {
                        EditCharges ec = new EditCharges(toEdit, this);
                        ec.Show();

                    }
                }
            }
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {
            Room done = RoomController.getById((int)r.RoomId);
            done.RoomStatus = "Free";
            this.Close();
        }
    }
}
