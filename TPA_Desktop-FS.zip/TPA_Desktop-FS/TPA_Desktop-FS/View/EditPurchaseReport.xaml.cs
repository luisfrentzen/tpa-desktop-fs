﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditPurchaseReport.xaml
    /// </summary>
    public partial class EditPurchaseReport : Window
    {
        PurchaseReport toEdit;
        Dashboard dbwindow;
        public EditPurchaseReport(PurchaseReport p, Dashboard d)
        {
            InitializeComponent();
            toEdit = p;
            dbwindow = d;

            purRepDate.SelectedDate = toEdit.DateBought.Value;
            purRepEmp.Text = toEdit.EmpId.ToString();
            purRepId.Text = toEdit.Id.ToString();
            purRepPrice.Text = toEdit.Price.ToString();
            purRepReq.Text = toEdit.ReqId.ToString();

            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            dbwindow.populatePurRepGd();
        }

        private void repUpdate_Click(object sender, RoutedEventArgs e)
        {
            if(purRepDate.SelectedDate.Value == null || purRepPrice.Text == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                int price;
                if (!int.TryParse(purRepPrice.Text, out price))
                {
                    ErrorWindow er = new ErrorWindow("price must be a number");
                    er.Show();
                }
                else
                {
                    toEdit.Price = price;
                    toEdit.DateBought = purRepDate.SelectedDate.Value;
                    errorMsg.Text = "report updated";
                    PurchaseReportController.update();
                }
            }
        }

        private void repDelete_Click(object sender, RoutedEventArgs e)
        {
            PurchaseReportController.delete(toEdit);
            this.Close();
        }
    }
}
