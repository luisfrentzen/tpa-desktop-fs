﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditMtReport.xaml
    /// </summary>
    public partial class EditMtReport : Window
    {
        MaintenanceReport mtrep;
        Dashboard db;
        public EditMtReport(MaintenanceReport mt, Dashboard dbwin)
        {
            InitializeComponent();
            mtrep = mt;
            db = dbwin;

            searchMtId.Text = mtrep.Id.ToString();
            mtDetails.Text = mtrep.MaintenanceDetail;

            searchMtId.IsEnabled = false;
        }

        private void updMtRep_Click(object sender, RoutedEventArgs e)
        {
            mtrep.MaintenanceDetail = mtDetails.Text;
            DbEntities.saves();
            this.Close();
        }

        private void delMtRep_Click(object sender, RoutedEventArgs e)
        {
            mtrep.IsDeleted = 1;
            DbEntities.saves();
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            db.populateMtRepGd();
        }
    }
}
