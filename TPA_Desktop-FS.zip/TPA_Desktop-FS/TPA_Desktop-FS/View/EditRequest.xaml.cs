﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditRequest.xaml
    /// </summary>
    public partial class EditRequest : Window
    {
        Request rq;
        Dashboard db;
        public EditRequest(Request r, Dashboard d)
        {
            InitializeComponent();
            rq = r;
            db = d;

            repDetails.Text = rq.Details;
            idText.Text = rq.Id.ToString();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            db.populatefundpurGd();
        }

        private void repUpdate_Click(object sender, RoutedEventArgs e)
        {
            string details = repDetails.Text;
            if(details == "")
            {
                errorMsg.Text = "please fill the necessary field(s)";
            }
            else
            {
                rq.Details = details;
                DbEntities.saves();
                this.Close();
            }
        }
    }
}
