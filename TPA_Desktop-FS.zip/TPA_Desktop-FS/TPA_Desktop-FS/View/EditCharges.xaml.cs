﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditCharges.xaml
    /// </summary>
    public partial class EditCharges : Window
    {
        RoomCharge rc;
        CleaningReport cr;
        public EditCharges(RoomCharge toedit, CleaningReport crWindow)
        {
            InitializeComponent();
            rc = toedit;
            cr = crWindow;

            name.Text = rc.Name;
            price.Text = rc.Price.ToString();

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            cr.populateCgGd();
        }

        private void itemDelete_Click(object sender, RoutedEventArgs e)
        {
            RoomChargesController.delete(rc);
            this.Close();
        }

        private void itemUpdate_Click(object sender, RoutedEventArgs e)
        {
            string item = name.Text;
            string pricetxt = price.Text;
            int amount;

            name.Text = "";
            price.Text = "";

            if (item == "" || pricetxt == "")
            {
                ErrorWindow er = new ErrorWindow("please fill necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(pricetxt, out amount))
                {
                    ErrorWindow er = new ErrorWindow("price must be a number");
                    er.Show();
                }
                else
                {
                    RoomChargesController.updateCharges(rc, item, amount);
                }
            }
        }
    }
}
