﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditResign.xaml
    /// </summary>
    public partial class EditResign : Window
    {
        ResignationRequest l;
        Dashboard db;

        public EditResign(ResignationRequest le, Dashboard dbwindow)
        {
            InitializeComponent();
            l = le;
            db = dbwindow;

            startDate.SelectedDate = l.ResignationDate.Value;
            leaveReason.Text = l.Details;
        }


        private void udpdateLeave_Click(object sender, RoutedEventArgs e)
        {
            string reason = leaveReason.Text;

            leaveReason.Text = "";

            if (reason == "" || startDate.SelectedDate == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                DateTime sDate = startDate.SelectedDate.Value;

                if((sDate - DateTime.Today).Days < 60)
                {
                    ErrorWindow er = new ErrorWindow("resignation must be atleast 2 months from today");
                    er.Show();
                }
                else
                {
                    startDate.SelectedDate = null;
                    l.Details = reason;
                    l.ResignationDate = sDate;

                    DbEntities.saves();
                    this.Close();
                }

                
            }
        }

        private void cancelLeave_Click(object sender, RoutedEventArgs e)
        {
            l.Status = "Completed";

            DbEntities.saves();
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            db.populateResignationGd();
        }

    }
}
