﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for editWpReport.xaml
    /// </summary>
    public partial class editWpReport : Window
    {
        WorkPerformance current;
        EmployeeInfo infoWindow;
        public editWpReport(WorkPerformance toEdit, EmployeeInfo window)
        {
            InitializeComponent();
            current = toEdit;
            infoWindow = window;
            showData();
        }

        private void showData()
        {
            if (current.ReportType == "Negative")
            {
                cmbRepType.SelectedIndex = 1;
            }
            else
            {
                cmbRepType.SelectedIndex = 0;
            }

            repDetails.Text = current.Report;
        }

        private void repDelete_Click(object sender, RoutedEventArgs e)
        {
            WorkPerformanceController.deleteWp(current.WpId);
            this.Close();
        }

        private void repUpdate_Click(object sender, RoutedEventArgs e)
        {
            string repType = cmbRepType.SelectedValue.ToString();
            string report = repDetails.Text;
            
            if(cmbRepType.SelectedValue == null || report == "")
            {
                errorMsg.Text = "please fill the necessary field(s)";
            }
            else
            {
                WorkPerformanceController.updateWp(current.WpId, repType, report);
                errorMsg.Text = "update success";
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            infoWindow.populateRepDg();
        }
    }
}
