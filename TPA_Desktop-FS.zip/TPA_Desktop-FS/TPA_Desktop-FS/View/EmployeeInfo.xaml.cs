﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EmployeeInfo.xaml
    /// </summary>
    public partial class EmployeeInfo : Window
    {
        Employee emp;
        public EmployeeInfo(Employee emp)
        {
            InitializeComponent();
            this.emp = emp;
            deptTxt.Text += emp.Department;
            nameTxt.Text += emp.Name;
            statTxt.Text += emp.Status;
            salaryTxt.Text += emp.Salary.ToString();
            populateRepDg();
            populateRdGd();
            populateRaiseGd();

            if(emp.Status == "Inactive")
            {
                reqRaise.IsEnabled = false;
                reqDismiss.IsEnabled = false;
                repSubmit.IsEnabled = false;
                cmbRepType.IsEnabled = false;
                repDetails.IsEnabled = false;
            }
        }

        private void repSubmit_Click(object sender, RoutedEventArgs e)
        {
            string report = repDetails.Text;
            if(report == "" || cmbRepType.SelectedValue == null)
            {
                errorMsg.Text = "Please fill the necessary field(s)";
            }
            else
            {
                string type = cmbRepType.SelectedValue.ToString();
                WorkPerformanceController.newWorkPerformance(emp.EmployeeId, type, report);
                errorMsg.Text = "";
                repDetails.Text = "";
                cmbRepType.SelectedIndex = -1;
                populateRepDg();
            }
        }

        public void populateRepDg()
        {
            List<WorkPerformance> workPerformances = WorkPerformanceController.getEmployeeWp(emp.EmployeeId);
            perfDg.IsReadOnly = true;
            perfDg.CanUserResizeColumns = false;
            perfDg.CanUserResizeRows = false;
            perfDg.CanUserSortColumns = false;
            perfDg.CanUserDeleteRows = false;
            perfDg.CanUserAddRows = false;
            perfDg.ItemsSource = workPerformances;
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            string searchTxt = searchWpId.Text;
            int wpId;
            if(searchTxt == "")
            {
                errorSearch.Text = "search field could not be empty";
            }
            else if(int.TryParse(searchTxt, out wpId) == false)
            {
                errorSearch.Text = "searched id must be a number";
            }
            else
            {
                WorkPerformance toEdit = WorkPerformanceController.getById(wpId);
                if(toEdit == null)
                {
                    errorSearch.Text = "report id not found";
                }
                else
                {
                    if(toEdit.EmpId == emp.EmployeeId)
                    {
                        errorSearch.Text = "";
                        editWpReport edit = new editWpReport(toEdit, this);
                        edit.Show();
                    }
                    else
                    {
                        errorSearch.Text = "report id not found";
                    }
                    
                }

            }
        }

        private void reqRaise_Click(object sender, RoutedEventArgs e)
        {
            string reason = raisedetails.Text;
            string raisetoTxt = raiseto.Text;
            int raise;
            if (reason == "" || raisetoTxt == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if(!int.TryParse(raisetoTxt, out raise))
                {
                    ErrorWindow er = new ErrorWindow("raise must be a number");
                    er.Show();
                }
                else if (RaiseController.getByEmp(emp).Count > 0)
                {
                    ErrorWindow er = new ErrorWindow("there is already an ongoin request");
                    er.Show();
                }
                else
                {
                    RaiseController.newRequest(emp, raise, reason);
                    populateRaiseGd();
                }
            }
        }

        public void populateRaiseGd()
        {
            List<Raise> data = RaiseController.getByEmp(emp);
            raiseGd.IsReadOnly = true;
            raiseGd.CanUserResizeColumns = false;
            raiseGd.CanUserResizeRows = false;
            raiseGd.CanUserSortColumns = false;
            raiseGd.CanUserDeleteRows = false;
            raiseGd.CanUserAddRows = false;
            raiseGd.ItemsSource = data;
        }

        private void populateRdGd()
        {
            List<Dismiss> data = DismissController.getByEmp(emp);
            rdGd.IsReadOnly = true;
            rdGd.CanUserResizeColumns = false;
            rdGd.CanUserResizeRows = false;
            rdGd.CanUserSortColumns = false;
            rdGd.CanUserDeleteRows = false;
            rdGd.CanUserAddRows = false;
            rdGd.ItemsSource = data;
        }

        private void reqDismiss_Click(object sender, RoutedEventArgs e)
        {

            string reason = raisedismissdetails.Text;
            raisedismissdetails.Text = "";
            if (reason == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (DismissController.getByEmp(emp).Count > 0)
                {
                    ErrorWindow er = new ErrorWindow("there is already an ongoin request");
                    er.Show();
                }
                else
                {
                    DismissController.newRequest(emp, reason);
                    populateRdGd();
                }
            }
        }

        private void editRaise_Click(object sender, RoutedEventArgs e)
        {
            if (RaiseController.getByEmp(emp).Count == 0)
            {
                ErrorWindow er = new ErrorWindow("no current request");
                er.Show();
            }
            else
            {
                Raise r = RaiseController.getByEmp(emp)[0];
                string reason = raisedetails.Text;
                string raisetoTxt = raiseto.Text;
                int raise;
                if (reason == "" || raisetoTxt == "")
                {
                    ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                    er.Show();
                }
                else
                {
                    if (!int.TryParse(raisetoTxt, out raise))
                    {
                        ErrorWindow er = new ErrorWindow("raise must be a number");
                        er.Show();
                    }
                    else
                    {
                        if(r.Status != "Pending")
                        {
                            ErrorWindow er = new ErrorWindow("can't edit this request");
                            er.Show();
                        }
                        else
                        {
                            r.RaiseTo = raise;
                            r.Reason = reason;
                            DbEntities.saves();
                            populateRaiseGd();

                        }
                    }
                }
            }
        }

        private void editDismiss_Click(object sender, RoutedEventArgs e)
        {

            if (DismissController.getByEmp(emp).Count == 0)
            {
                ErrorWindow er = new ErrorWindow("no current request");
                er.Show();
            }
            else
            {
                string reason = raisedismissdetails.Text;
                if(reason == "")
                {
                    ErrorWindow er = new ErrorWindow("please fill necessary field(s)");
                    er.Show();
                }
                else
                {
                    Dismiss d = DismissController.getByEmp(emp)[0];
                    if (d.Status != "Pending")
                    {
                        ErrorWindow er = new ErrorWindow("can't edit this request");
                        er.Show();
                    }
                    else
                    {
                        d.Reason = reason;
                        DbEntities.saves();
                        populateRdGd();
                    }
                }
            }
        }

        private void cancelDismiss_Click(object sender, RoutedEventArgs e)
        {
            if (DismissController.getByEmp(emp).Count == 0)
            {
                ErrorWindow er = new ErrorWindow("no current request");
                er.Show();
            }
            else
            {
                Dismiss r = DismissController.getByEmp(emp)[0];


                if (r.Status != "Pending")
                {
                    ErrorWindow er = new ErrorWindow("can't edit this request");
                    er.Show();
                }
                else
                {
                    r.Status = "Completed";
                    DbEntities.saves();
                    populateRdGd();

                }

            }
        }

        private void cancelRaise_Click(object sender, RoutedEventArgs e)
        {
            if (RaiseController.getByEmp(emp).Count == 0)
            {
                ErrorWindow er = new ErrorWindow("no current request");
                er.Show();
            }
            else
            {
                Raise r = RaiseController.getByEmp(emp)[0];
               
                
                if (r.Status != "Pending")
                {
                    ErrorWindow er = new ErrorWindow("can't edit this request");
                    er.Show();
                }
                else
                {
                    r.Status = "Completed";
                    DbEntities.saves();
                    populateRaiseGd();

                }
                 
            }
        }
    }
}
