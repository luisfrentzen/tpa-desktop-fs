﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EmployeeInfo.xaml
    /// </summary>
    public partial class EmployeeInfo : Window
    {
        public EmployeeInfo(Employee emp)
        {
            InitializeComponent();
            deptTxt.Text += emp.Department;
            nameTxt.Text += emp.Name;
            statTxt.Text += emp.Status;
            salaryTxt.Text += emp.Salary.ToString();
        }
    }
}
