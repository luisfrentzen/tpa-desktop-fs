﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditAttractionRide.xaml
    /// </summary>
    public partial class EditAttractionRide : Window
    {
        AttractionRide ar;
        Dashboard db;
        public EditAttractionRide(AttractionRide edit, Dashboard dbwindow)
        {
            InitializeComponent();
            ar = edit;
            db = dbwindow;

            newAttractionName.Text = ar.Name;
            planDesc.Text = ar.Details;

            if(ar.Type == "Attraction")
            {
                cmbPlanType.SelectedIndex = 1;
                reqMt.IsEnabled = false;
            }
            else
            {
                cmbPlanType.SelectedIndex = 0;
            }

            cmbPlanType.IsEnabled = false;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            db.populateSubmissionGd();
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            if (PlanSubmissionController.getPlanByAttride(ar) == null)
            {
                PlanSubmissionController.removeAttractionRide(ar);
                errorMsg.Text = "submission sent";
            }
            else
            {
                ErrorWindow er = new ErrorWindow("there is already a submission on the same attraction/ride");
                er.Show();
            }
        }

        private void done_Click(object sender, RoutedEventArgs e)
        {
            string name = newAttractionName.Text;
            string details = planDesc.Text;

            if(name == "" || details == "")
            {
                ErrorWindow er = new ErrorWindow("please fill necessary field(s)");
                er.Show();
            }
            else
            {
                if(PlanSubmissionController.getPlanByAttride(ar) == null)
                {
                   PlanSubmissionController.updateAttractionRide(ar, name, details);
                   errorMsg.Text = "submission sent";
                }
                else
                {
                    ErrorWindow er = new ErrorWindow("unable to edit attraction/ride");
                    er.Show();
                }
            }

        }

        private void reqMt_Click(object sender, RoutedEventArgs e)
        {
            ar.Status = "Request Maintenance";
            DbEntities.saves();
            errorMsg.Text = "maintenance requested";
        }
    }
}
