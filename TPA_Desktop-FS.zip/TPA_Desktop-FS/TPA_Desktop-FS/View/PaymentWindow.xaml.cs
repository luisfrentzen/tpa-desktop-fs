﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for PaymentWindow.xaml
    /// </summary>
    public partial class PaymentWindow : Window
    {
        Window tbInfo;
        string dept;
        int totalPrice;
        public PaymentWindow(int amount, Window tbwindow, string type)
        {
            InitializeComponent();
            tbInfo = tbwindow;
            totalPrice = amount;
            dept = type;
            amountTxt.Text = totalPrice.ToString();
        }

        private void addReview_Click(object sender, RoutedEventArgs e)
        {
            string rating = "-";
            if(rate1.IsChecked == true)
            {
                rating = "1";
            }
            else if (rate2.IsChecked == true)
            {
                rating = "2";
            }
            else if (rate3.IsChecked == true)
            {
                rating = "3";
            }
            else if (rate4.IsChecked == true)
            {
                rating = "4";
            }
            else if (rate5.IsChecked == true)
            {
                rating = "5";
            }
            
            Transaction current = TransactionController.newTransaction(totalPrice, dept);

            string feedback = feedbackTxt.Text;
            if(feedback == "")
            {
                feedback = "-";
            }

            if(feedback == "-" && rating == "-")
            {

            }
            else
            {
                FeedbackController.newFeedback(current.TrId, rating, feedback, dept);
            }
            this.Close();
            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if(tbInfo != null)
            {
                tbInfo.Close();
            }
        }
    }
}
