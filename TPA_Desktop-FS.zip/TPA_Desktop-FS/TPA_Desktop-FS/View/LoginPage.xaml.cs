﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void loginButton_Click(object sender, RoutedEventArgs e)
        {
            String username = unameText.Text;
            String password = pwdText.Password;

            Employee user = EmployeeController.userLogin(username, password);
            if(user != null)
            {
                Dashboard dash = new Dashboard(user);
                dash.Show();
                
                this.Close();
            }
            else
            {
                unameText.Text = "";
                pwdText.Password = "";
                errorText.Text = "Invalid Username/Password";
            }
        }
    }
}
