﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for TableInfo.xaml
    /// </summary>
    public partial class TableInfo : Window
    {
        Table toEdit;
        Dashboard dbWindow;

        public TableInfo(Table edit, Dashboard window)
        {
            InitializeComponent();
            toEdit = edit;
            dbWindow = window;

            OrdType.Text = toEdit.Type;
            status.Text = toEdit.TableStatus;
            id.Text = toEdit.TableId.ToString();
            populateTableOrderGd();
        }

        public void populateTableOrderGd()
        {
            List<Order> data = OrderController.getAllByTable(toEdit.TableId);
            dgOrder.CanUserResizeColumns = false;
            dgOrder.CanUserResizeRows = false;
            dgOrder.CanUserSortColumns = false;
            dgOrder.IsReadOnly = true;
            dgOrder.CanUserDeleteRows = false;
            dgOrder.CanUserAddRows = false;
            dgOrder.ItemsSource = data;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            dbWindow.populateTbGd();
            dbWindow.populateOrdGd();
        }

        private void tbComplete_Click(object sender, RoutedEventArgs e)
        {
            List<Order> data = OrderController.getAllByTable(toEdit.TableId);
            if (!data.Any())
            {
                errorMsg.Text = "there is no order";
            }
            else
            {
                errorMsg.Text = "";
                int amount = TableController.getTotal(toEdit);
                PaymentWindow pwin = new PaymentWindow(amount, this, "Restaurant");
                pwin.Show();
                TableController.cancelTable(toEdit.TableId);
            }
        }

        private void orderSeach_Click(object sender, RoutedEventArgs e)
        {
            string idTxt = orderIdSearch.Text;
            int id;
            if(idTxt == "")
            {
                errorMsg.Text = "please fill the necessary field(s)";
            }
            else
            {
                if(!int.TryParse(idTxt, out id))
                {
                    errorMsg.Text = "id must be a number";
                }
                else
                {
                    Order editOrder = OrderController.getTableOder(id, toEdit.TableId);
                    
                    if(editOrder == null)
                    {
                        errorMsg.Text = "no such order";
                    }
                    else
                    {
                        editOrder editWindow = new View.editOrder(editOrder, this);
                        editWindow.Show();
                    }

                }
            }
        }

        private void tbCancel_Click(object sender, RoutedEventArgs e)
        {
            TableController.cancelTable(toEdit.TableId);
            this.Close();
        }
    }
}
