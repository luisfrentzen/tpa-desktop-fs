﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    /// 

    public partial class Dashboard : Window
    {
        public Employee user;

        public Dashboard()
        {
            LoginPage login = new LoginPage();
            this.Close();
            login.Show();
        }
        public Dashboard(Employee user)
        {
            InitializeComponent();
            this.user = user;
            empNameText.Text += user.Name;
            empDivText.Text = user.Department;

            Style st = FindResource("setVisible") as Style;
            Style hide = FindResource("setInvisible") as Style;
            if (user.Department == "Attraction Department")
            {
                Attraction.Style = st;
                populateTrGd("Ticket");
                submitFund.IsEnabled = false;
                submitPurchase.IsEnabled = false;
                fundpurchase.Style = hide;
            }
            else if(user.Department == "Human Resource Department")
            {
                Hrd.Style = st;
                populateEmployeeGd();

                populatehrLeaveGd();
                submitPurchase.IsEnabled = false;
            }
            else if(user.Department == "Manager")
            {
                Manager.Style = st;

                submitPurchase.IsEnabled = false;
                submitFund.IsEnabled = false;
                fundpurchase.Style = hide;
            }
            else if(user.Department == "Sales and Marketing Department")
            {
                Sales.Style = st;
                populateAdGd();
                populateVisitorGd();

                submitFund.IsEnabled = false;
            }
            else if(user.Department == "Restaurant - Dining Division")
            {
                Dining.Style = st;
                populateOrdGd();
                populateTbGd();

                submitPurchase.IsEnabled = false;
                submitFund.IsEnabled = false;
                fundpurchase.Style = hide;
            }
            else if (user.Department == "Restaurant - Kitchen Division")
            {
                Kitchen.Style = st;
                populateOrdGd2();

                submitFund.IsEnabled = false;
            }
            else if(user.Department == "Hotel - Front Office Division")
            {
                Front.Style = st;
                populateRoomGd();
                populateRsvGd();

                submitPurchase.IsEnabled = false;
                submitFund.IsEnabled = false;
                fundpurchase.Style = hide;
            }
            else if (user.Department == "Hotel - Housekeeping Division")
            {
                housek.Style = st;
                populateRsvGd2();

                submitPurchase.IsEnabled = false;
                submitFund.IsEnabled = false;
                fundpurchase.Style = hide;

            }
            else if(user.Department == "Construction Department")
            {
                Construction.Style = st;
                populateplanGd();
            }
            else if(user.Department == "Maintenance Department")
            {
                Maintenance.Style = st;
                mtReports.Style = st;

                submitPurchase.IsEnabled = false;
                submitFund.IsEnabled = false;
                fundpurchase.Style = hide;
                populateReqMtGd();
                populateMtGd();
                populateMtRepGd();
            }
            else if(user.Department == "Accounting and Finance Department")
            {
                Accounting.Style = st;
                populateRequestGd(fundGd, "Fund");
                submitPurchase.IsEnabled = false;
                submitFund.IsEnabled = false;
                fundpurchase.Style = hide;
            }
            else if(user.Department == "Purchasing Department")
            {
                Purchase.Style = st;
                populateRequestGd(purcGd, "Purchase");
                submitPurchase.IsEnabled = false;
                populatePurRepGd();
            }
            else if(user.Department == "Attraction and Ride Creative Department")
            {
                Creative.Style = st;
                populateSubmissionGd();
                populateAttrideGd();
            }

            populatefundpurGd();
            populateResignationGd();
            populateLeaveGd();
        }



        public void populateReqMtGd()
        {
            List<AttractionRide> data = AttractionRideController.getAllReqMt();
            mtschedGd.IsReadOnly = true;
            mtschedGd.CanUserResizeColumns = false;
            mtschedGd.CanUserResizeRows = false;
            mtschedGd.CanUserSortColumns = false;
            mtschedGd.CanUserDeleteRows = false;
            mtschedGd.CanUserAddRows = false;
            mtschedGd.ItemsSource = data;
        }

        public void populateMtGd()
        {
            List<MaintenanceSchedule> data = MaintenanceController.getAll();
            mtattrideGd.IsReadOnly = true;
            mtattrideGd.CanUserResizeColumns = false;
            mtattrideGd.CanUserResizeRows = false;
            mtattrideGd.CanUserSortColumns = false;
            mtattrideGd.CanUserDeleteRows = false;
            mtattrideGd.CanUserAddRows = false;
            mtattrideGd.ItemsSource = data;
        }


        public void populateRequestGd(DataGrid gd, string v)
        {
            List<Request> data = RequestController.getAllByType(v);
            gd.IsReadOnly = true;
            gd.CanUserResizeColumns = false;
            gd.CanUserResizeRows = false;
            gd.CanUserSortColumns = false;
            gd.CanUserDeleteRows = false;
            gd.CanUserAddRows = false;
            gd.ItemsSource = data;
        }

        public void populatefundpurGd()
        {
            List<Request> data = RequestController.getAllByEmpByType(user, "Purchase");
            List<Request> data2 = RequestController.getAllByEmpByType(user, "Fund");
            data = data.Concat<Request>(data2).ToList<Request>();
            fundpurchGd.IsReadOnly = true;
            fundpurchGd.CanUserResizeColumns = false;
            fundpurchGd.CanUserResizeRows = false;
            fundpurchGd.CanUserSortColumns = false;
            fundpurchGd.CanUserDeleteRows = false;
            fundpurchGd.CanUserAddRows = false;
            fundpurchGd.ItemsSource = data;
        }

        public void populateAttrideGd()
        {
            List<AttractionRide> data = AttractionRideController.getAll();
            attrideGd.IsReadOnly = true;
            attrideGd.CanUserResizeColumns = false;
            attrideGd.CanUserResizeRows = false;
            attrideGd.CanUserSortColumns = false;
            attrideGd.CanUserDeleteRows = false;
            attrideGd.CanUserAddRows = false;
            attrideGd.ItemsSource = data;
        }

        public void populateSubmissionGd()
        {
            List<PlanSubmission> data = PlanSubmissionController.getAll();
            submissionGd.IsReadOnly = true;
            submissionGd.CanUserResizeColumns = false;
            submissionGd.CanUserResizeRows = false;
            submissionGd.CanUserSortColumns = false;
            submissionGd.CanUserDeleteRows = false;
            submissionGd.CanUserAddRows = false;
            submissionGd.ItemsSource = data;
        }

        public void populateplanGd()
        {
            List<PlanSubmission> data = PlanSubmissionController.getAllPlan();
            planGd.IsReadOnly = true;
            planGd.CanUserResizeColumns = false;
            planGd.CanUserResizeRows = false;
            planGd.CanUserSortColumns = false;
            planGd.CanUserDeleteRows = false;
            planGd.CanUserAddRows = false;
            planGd.ItemsSource = data;
        }

        public void populateMtRepGd()
        {
            List<MaintenanceReport> data = MaintenanceReportController.getAll();
            mtRepGd.IsReadOnly = true;
            mtRepGd.CanUserResizeColumns = false;
            mtRepGd.CanUserResizeRows = false;
            mtRepGd.CanUserSortColumns = false;
            mtRepGd.CanUserDeleteRows = false;
            mtRepGd.CanUserAddRows = false;
            mtRepGd.ItemsSource = data;
        }

        public void populateLeaveGd()
        {
            List<LeaveRequest> data = LeaveRequestController.getAllByEmp(user);
            leaveGd.IsReadOnly = true;
            leaveGd.CanUserResizeColumns = false;
            leaveGd.CanUserResizeRows = false;
            leaveGd.CanUserSortColumns = false;
            leaveGd.CanUserDeleteRows = false;
            leaveGd.CanUserAddRows = false;
            leaveGd.ItemsSource = data;
        }

        public void populatehrLeaveGd()
        {
            List<LeaveRequest> data = LeaveRequestController.getAll();
            hrleaveGd.IsReadOnly = true;
            hrleaveGd.CanUserResizeColumns = false;
            hrleaveGd.CanUserResizeRows = false;
            hrleaveGd.CanUserSortColumns = false;
            hrleaveGd.CanUserDeleteRows = false;
            hrleaveGd.CanUserAddRows = false;
            hrleaveGd.ItemsSource = data;
        }

        public void populateResignationGd()
        {
            List<ResignationRequest> data = ResignationRequestController.getAllByEmp(user);
            resignGd.IsReadOnly = true;
            resignGd.CanUserResizeColumns = false;
            resignGd.CanUserResizeRows = false;
            resignGd.CanUserSortColumns = false;
            resignGd.CanUserDeleteRows = false;
            resignGd.CanUserAddRows = false;
            resignGd.ItemsSource = data;
        }

        public void populatehrResignationGd()
        {
            List<ResignationRequest> data = ResignationRequestController.getAll();
            //hrresignGd.IsReadOnly = true;
            //resignGd.CanUserResizeColumns = false;
            //resignGd.CanUserResizeRows = false;
            //resignGd.CanUserSortColumns = false;
            //resignGd.CanUserDeleteRows = false;
            //resignGd.CanUserAddRows = false;
            //resignGd.ItemsSource = data;
        }

        public void populateOrdGd()
        {
            List<Order> ord = OrderController.getAll();
            dgOrder.IsReadOnly = true;
            dgOrder.CanUserResizeColumns = false;
            dgOrder.CanUserResizeRows = false;
            dgOrder.CanUserSortColumns = false;
            dgOrder.CanUserDeleteRows = false;
            dgOrder.CanUserAddRows = false;
            dgOrder.ItemsSource = ord;
        }
        public void populateRsvGd()
        {
            List<Reservation> data = ReservationController.getAll();
            dgReservation.IsReadOnly = true;
            dgReservation.CanUserResizeColumns = false;
            dgReservation.CanUserResizeRows = false;
            dgReservation.CanUserSortColumns = false;
            dgReservation.CanUserDeleteRows = false;
            dgReservation.CanUserAddRows = false;
            dgReservation.ItemsSource = data;
        }

        public void populateRsvGd2()
        {
            List<Room> data = RoomController.getAll();
            dgReservation2.IsReadOnly = true;
            dgReservation2.CanUserResizeColumns = false;
            dgReservation2.CanUserResizeRows = false;
            dgReservation2.CanUserSortColumns = false;
            dgReservation2.CanUserDeleteRows = false;
            dgReservation2.CanUserAddRows = false;
            dgReservation2.ItemsSource = data;
        }

        public void populateRoomGd()
        {
            List<Room> data = RoomController.getAll();
            dgRoom.IsReadOnly = true;
            dgRoom.CanUserResizeColumns = false;
            dgRoom.CanUserResizeRows = false;
            dgRoom.CanUserSortColumns = false;
            dgRoom.CanUserDeleteRows = false;
            dgRoom.CanUserAddRows = false;
            dgRoom.ItemsSource = data;
        }

        public void populatePurRepGd()
        {
            List<PurchaseReport> data = PurchaseReportController.getAll();
            purchaseRepGd.IsReadOnly = true;
            purchaseRepGd.CanUserResizeColumns = false;
            purchaseRepGd.CanUserResizeRows = false;
            purchaseRepGd.CanUserSortColumns = false;
            purchaseRepGd.CanUserDeleteRows = false;
            purchaseRepGd.CanUserAddRows = false;
            purchaseRepGd.ItemsSource = data;
        }

        public void populateOrdGd2()
        {
            List<Order> ord = OrderController.getAll();
            dgOrder2.IsReadOnly = true;
            dgOrder2.CanUserResizeColumns = false;
            dgOrder2.CanUserResizeRows = false;
            dgOrder2.CanUserSortColumns = false;
            dgOrder2.CanUserDeleteRows = false;
            dgOrder2.CanUserAddRows = false;
            dgOrder2.ItemsSource = ord;
        }

        public void populateTbGd()
        {
            List<Table> tb = TableController.getAll();
            dgTable.IsReadOnly = true;
            dgTable.CanUserResizeColumns = false;
            dgTable.CanUserResizeRows = false;
            dgTable.CanUserSortColumns = false;
            dgTable.CanUserDeleteRows = false;
            dgTable.CanUserAddRows = false;
            dgTable.ItemsSource = tb;
        }
        public void populateTrGd(string category)
        {
            List<Transaction> tr = TransactionController.getAllByDept("Ticket");
            transactionGd.IsReadOnly = true;
            transactionGd.CanUserResizeColumns = false;
            transactionGd.CanUserResizeRows = false;
            transactionGd.CanUserSortColumns = false;
            transactionGd.CanUserDeleteRows = false;
            transactionGd.CanUserAddRows = false;
            transactionGd.ItemsSource = tr;
        }

        public void populateAdGd()
        {
            List<Advertisement> ads = AdvertisementController.getAll();
            dgAds.IsReadOnly = true;
            dgAds.CanUserResizeColumns = false;
            dgAds.CanUserResizeRows = false;
            dgAds.CanUserSortColumns = false;
            dgAds.CanUserDeleteRows = false;
            dgAds.CanUserAddRows = false;
            dgAds.ItemsSource = ads;
        }
        private void populateVisitorGd()
        {
            List<ParkInfo> data = TicketController.getParkInfo();
            dgVisitor.IsReadOnly = true;
            dgVisitor.CanUserResizeColumns = false;
            dgVisitor.CanUserResizeRows = false;
            dgVisitor.CanUserSortColumns = false;
            dgVisitor.CanUserDeleteRows = false;
            dgVisitor.CanUserAddRows = false;
            dgVisitor.ItemsSource = data;
        }

        private void populateEmployeeGd()
        {
            List<Employee> employees = EmployeeController.getAllEmployee();
            dgEmployee.IsReadOnly = true;
            dgEmployee.CanUserResizeColumns = false;
            dgEmployee.CanUserResizeRows = false;
            dgEmployee.CanUserSortColumns = false;
            dgEmployee.CanUserDeleteRows = false;
            dgEmployee.CanUserAddRows = false;
            dgEmployee.ItemsSource = employees;

        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            this.user = null;
            LoginPage login = new LoginPage();
            this.Close();
            login.Show();
        }

        private void newEmpButton_Click(object sender, RoutedEventArgs e)
        {
            newEmployee regEmp = new newEmployee();
            regEmp.Show();
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            String name = searchBox.Text;
            if(name != "")
            {
                Employee empFound = EmployeeController.getByName(name);
                if(empFound == null)
                {
                    ErrorWindow notFound = new ErrorWindow("Employee not found");
                    notFound.Show();
                }
                else
                {
                    searchBox.Text = "";
                    EmployeeInfo found = new EmployeeInfo(empFound);
                    found.Show();
                }
            }
        }

        private void genBtn_Click(object sender, RoutedEventArgs e)
        {
            Ticket newTicket = TicketController.newTicket();
            qrCodeImg.Source = TicketController.generateQr(newTicket);
            tickId.Text = newTicket.TicketId;
        }

        private void valBtn_Click(object sender, RoutedEventArgs e)
        {
            String ticketId = inputIdTxt.Text;
            inputIdTxt.Text = "";
            int isValidated = TicketController.validateTicket(ticketId);
            if(isValidated == -1)
            {
                errorMsg.Text = "Ticket is Out of Date";
            }
            else if(isValidated == 1)
            {
                errorMsg.Text = "Ticket Invalid";
            }
            else if(isValidated == 2)
            {
                errorMsg.Text = "Ticket Already Activated";
            }
            else 
            {
                errorMsg.Text = "Ticket Validated";
            }
        }

        private void addAd_Click(object sender, RoutedEventArgs e)
        {
            string name = adName.Text;
            string type = adType.Text;

            if(name == "" || type == "")
            {
                errorMsgAd.Text = "please fill necessary field(s)";
            }
            else
            {
                errorMsgAd.Text = "";
                adName.Text = "";
                adType.Text = "";

                AdvertisementController.newAdd(name, type);
                populateAdGd();
            }
        }

        private void searchAdBtn_Click(object sender, RoutedEventArgs e)
        {
            String textId = searchAdId.Text;
            int id;
            if (textId == "")
            {
                ErrorWindow error = new ErrorWindow("Please enter necessary field(s)");
                error.Show();
            }
            else
            {
                if(!int.TryParse(textId, out id))
                {
                    ErrorWindow wrongFormat = new ErrorWindow("Search id must be a number");
                    wrongFormat.Show();
                }
                else
                {
                    Advertisement ad = AdvertisementController.getById(id);
                    if (ad == null)
                    {
                        ErrorWindow notFound = new ErrorWindow("Advertisement not found");
                        notFound.Show();
                    }
                    else
                    {
                        searchAdId.Text = "";
                        AdInfo toEdit = new AdInfo(ad, this);
                        toEdit.Show();
                    }
                }
                
            }
        }

        private void delBtn_Click(object sender, RoutedEventArgs e)
        {
            string ticketId = inputIdTxt.Text;
            inputIdTxt.Text = "";
            if(ticketId == "")
            {
                errorMsg.Text = "please fill the necessary field(s)";
            }
            else
            {
                Ticket toDel = TicketController.getById(ticketId);
                if(toDel == null)
                {
                    errorMsg.Text = "ticket id is not valid";
                }
                else
                {
                    TicketController.deactivateTicket(toDel);
                    errorMsg.Text = "ticket deactivated";
                }
            }
        }

        private void searchTrBtn_Click(object sender, RoutedEventArgs e)
        {
            string editText = searchTrId.Text;
            searchTrId.Text = "";
            int id;
            if (editText == "")
            {
                ErrorWindow empty = new ErrorWindow("please fill the necessary field(s)");
                empty.Show();
            }
            else
            {
                if (!int.TryParse(editText, out id))
                {
                    ErrorWindow wrongformat = new ErrorWindow("ticket id must be a number");
                    wrongformat.Show();
                }
                else
                {
                    Transaction toEdit = TransactionController.getById(id, "Ticket");
                    if(toEdit == null)
                    {
                        ErrorWindow notfound = new ErrorWindow("transaction not found");
                        notfound.Show();
                    }
                    else
                    {
                        EditTransaction edit = new EditTransaction(toEdit, this);
                        edit.Show();
                    }
                }
            }
        }

        private void addTr_Click(object sender, RoutedEventArgs e)
        {
            string amText = tickAmt.Text;
            tickAmt.Text = "";
            int amt;
            if (amText == "")
            {
                ErrorWindow empty = new ErrorWindow("please fill the necessary field(s)");
                empty.Show();
            }
            else
            {
                if (!int.TryParse(amText, out amt))
                {
                    ErrorWindow wrongformat = new ErrorWindow("ticket amount must be a number");
                    wrongformat.Show();
                }
                else
                {
                    TransactionController.newTransaction(amt * 100000, "Ticket");
                    populateTrGd("Ticket");
                }
            }
        }

        private void OrderAdd_Click(object sender, RoutedEventArgs e)
        {
            string menu = OrdName.Text;
            string pricetxt = MenuPrice.Text;
            string tableIdtxt = TableId.Text;
            string ordType;
            string qtyTxt = qtyText.Text;
            int qty;
            int ordPrice;
            int id;

            if(menu == "" || pricetxt == "" || cmbOrdType.SelectedValue == null || tableIdtxt == "" || qtyTxt == "")
            {
                ErrorWindow fill = new ErrorWindow("please fill the necessary field(s)");
                fill.Show();
            }
            else
            {
                if(!int.TryParse(pricetxt, out ordPrice))
                {
                    ErrorWindow wrongformat = new ErrorWindow("price must be a number");
                    wrongformat.Show();
                }
                else if (!int.TryParse(tableIdtxt, out id))
                {
                    ErrorWindow wrongformat = new ErrorWindow("id must be a number");
                    wrongformat.Show();
                }
                else if (!int.TryParse(qtyTxt, out qty))
                {
                    ErrorWindow wrongformat = new ErrorWindow("quantity must be a number");
                    wrongformat.Show();
                }
                else
                {
                    ordType = cmbOrdType.SelectedValue.ToString();
                    Table curr = TableController.getById(id);
                    if (ordType == "Dine In" &&  curr == null)
                    {
                        ErrorWindow tblnotfound = new ErrorWindow("no such table exist");
                        tblnotfound.Show();
                        return;
                    }
                    else if(ordType =="Take Away" && curr == null)
                    {
                        curr = TableController.newTakeAway(id);
                    }
                    else if(ordType == "Take Away")
                    {
                        TableController.updateTable(curr.TableId, "Add");
                    }
                    else if(ordType != curr.Type)
                    {
                        ErrorWindow tblnotfound = new ErrorWindow("order and table type does not match");
                        tblnotfound.Show();
                        return;
                    }

                    OrdName.Text = "";
                    MenuPrice.Text = "";
                    TableId.Text = "";
                    qtyText.Text = "";
                    cmbOrdType.SelectedIndex = -1;

                    OrderController.addOrder(menu, id, ordPrice, ordType, qty);
                    populateOrdGd();
                    populateTbGd();
                }
            }
        }

        private void searchTbId_Click(object sender, RoutedEventArgs e)
        {
            string idTxt = searchTbId.Text;
            searchTbId.Text = "";
            int id;
            if(idTxt == "")
            {
                ErrorWindow fill = new ErrorWindow("please fill the necessary field(s)");
                fill.Show();
            }
            else
            {
                if(!int.TryParse(idTxt, out id))
                {
                    ErrorWindow wrongformat = new ErrorWindow("price must be a number");
                    wrongformat.Show();
                }
                else
                {
                    Table tb = TableController.getById(id);
                    if(tb == null)
                    {
                        ErrorWindow tblnotfound = new ErrorWindow("no such table exist");
                        tblnotfound.Show();
                    }
                    else
                    {
                        TableInfo tbInfo = new TableInfo(tb, this);
                        tbInfo.Show();
                    }
                }
            }
        }

        private void valBtn2_Click(object sender, RoutedEventArgs e)
        {
            String ticketId = inputIdTxt2.Text;
            inputIdTxt2.Text = "";
            int isValidated = TicketController.validateTicket(ticketId);
            if (isValidated == -1)
            {
                errorMsgDine.Text = "Ticket is Out of Date";
            }
            else if (isValidated == 1)
            {
                errorMsgDine.Text = "Ticket Invalid";
            }
            else
            {
                errorMsgDine.Text = "Ticket Validated";
            }
        }

        private void viewFeedback_Click(object sender, RoutedEventArgs e)
        {
            string type;
            if(user.Department == "Restaurant - Kitchen Division" || user.Department == "Restaurant - Dining Division")
            {
                type = "Restaurant";
            }
            else
            {
                type = "Hotel";
            }

            ViewFeedback viewFb = new ViewFeedback(type);
            viewFb.Show();
        }

        private void searchOrBtn_Click(object sender, RoutedEventArgs e)
        {
            string idText = searchOrId.Text;
            int id;
            if(idText == "")
            {
                ErrorWindow emp = new ErrorWindow("please fill the necessary field(s)");
                emp.Show();
            }
            else
            {
                if(!int.TryParse(idText, out id))
                {
                    ErrorWindow wformat = new ErrorWindow("id must be a number");
                    wformat.Show();
                }
                else
                {
                    Order found = OrderController.getById(id);
                    if(found == null)
                    {
                        ErrorWindow notfound = new ErrorWindow("no such order");
                        notfound.Show();
                    }
                    else
                    {
                        found.IsCompleted = 1;
                        OrderController.updateOrder(found);
                        searchOrId.Text = "";
                        populateOrdGd2();
                    }
                }
            }
        }

        private void addReservation_Click(object sender, RoutedEventArgs e)
        {
            string name = visitorName.Text;
            string idTxt = visitorId.Text;
            string roomTxt = RoomId.Text;
            int roomId;
            if(name == "" || idTxt == "" || roomTxt == "" || checkinDp.SelectedDate == null || checkoutDp.SelectedDate == null)
            {
                ErrorWindow emp = new ErrorWindow("please fill the necessary field(s)");
                emp.Show();
            }
            else
            {
                DateTime checkin = (DateTime)checkinDp.SelectedDate;
                DateTime checkout = (DateTime)checkoutDp.SelectedDate;
                DateTime today = DateTime.Now;

                if(!int.TryParse(roomTxt, out roomId))
                {
                    ErrorWindow wformat = new ErrorWindow("room number must be a number");
                    wformat.Show();
                }
                else if(DateTime.Compare(checkin, today) < 0)
                {
                    ErrorWindow wrongformat = new ErrorWindow("can't reserve for the past");
                    wrongformat.Show();
                }
                else if(DateTime.Compare(checkout, checkin) <= 0)
                {
                    ErrorWindow wrongformat = new ErrorWindow("please input a correct date");
                    wrongformat.Show();
                }
                else if(RoomController.getById(roomId) == null)
                {
                    ErrorWindow wrongformat = new ErrorWindow("please input a valid room number");
                    wrongformat.Show();
                }
                else if (!ReservationController.checkReservation(roomId,checkin,checkout))
                {
                    ErrorWindow wrongformat = new ErrorWindow("this room is reserved for the current dates");
                    wrongformat.Show();
                }
                else
                {
                    HotelVisitor occupant = HotelVisitorController.getById(idTxt);
                    if(occupant == null)
                    {
                        HotelVisitorController.newVisitor(name, idTxt);
                    }

                    ReservationController.newReservation(name, idTxt, checkin, checkout, roomId);
                    populateRsvGd();
                }
            }

            
        }

        private void checkInBtn_Click(object sender, RoutedEventArgs e)
        {
            int id;
            string idTxt = reservationId.Text;
            int currHour = int.Parse(DateTime.Now.ToString("HH"));

            reservationId.Text = "";

            if(currHour < 10)
            {
                ErrorWindow wrongHour = new ErrorWindow("check in should be done after 10 am");
                wrongHour.Show();
            }
            else
            {
                if(idTxt == "")
                {
                    ErrorWindow wrongFormat = new ErrorWindow("please fill the necessary field(s)");
                    wrongFormat.Show();
                }
                else if(!int.TryParse(idTxt, out id))
                {
                    ErrorWindow wrongFormat = new ErrorWindow("id must be a number");
                    wrongFormat.Show();
                }
                else
                {
                    ReservationController.checkIn(id);
                    populateRsvGd();
                    populateRoomGd();
                }
            }
        }

        private void checkOutBtn_Click(object sender, RoutedEventArgs e)
        {
            int id;
            string idTxt = reservationId.Text;

            reservationId.Text = "";

            int currHour = int.Parse(DateTime.Now.ToString("HH"));


            if (currHour >= 8)
            {
                ErrorWindow wrongHour = new ErrorWindow("check out should be done before 8 am");
                wrongHour.Show();
            }
            else
            {
                if (idTxt == "")
                {
                    ErrorWindow wrongFormat = new ErrorWindow("please fill the necessary field(s)");
                    wrongFormat.Show();
                }
                else if (!int.TryParse(idTxt, out id))
                {
                    ErrorWindow wrongFormat = new ErrorWindow("id must be a number");
                    wrongFormat.Show();
                }
                else
                {
                    Reservation temp = ReservationController.getById(id);
                    if (temp == null)
                    {
                        ErrorWindow er = new ErrorWindow("no such reservation");
                        er.Show();
                    }
                    else if (temp.Status != "Currently")
                    {
                        ErrorWindow er = new ErrorWindow("this reservation can't be checked out");
                        er.Show();
                    }
                    else
                    {
                        Room r = RoomController.getById((int)temp.RoomId);
                        if (r.RoomStatus == "Occupied")
                        {
                            r.RoomStatus = "Checkout";
                            ErrorWindow er = new ErrorWindow("waiting for cleaning");
                            er.Show();
                        }
                        else if (r.RoomStatus == "Checkout")
                        {
                            ErrorWindow er = new ErrorWindow("waiting for cleaning");
                            er.Show();
                        }
                        else if (r.RoomStatus == "Free")
                        {
                            r.OccupantId = null;
                            Checkout c = new Checkout(temp, this);
                            c.Show();
                        }
                    }
                    populateRsvGd();
                    populateRoomGd();
                }
            }
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e)
        {
            int id;
            string idTxt = reservationId.Text;

            reservationId.Text = "";

            if (idTxt == "")
            {
                ErrorWindow wrongFormat = new ErrorWindow("please fill the necessary field(s)");
                wrongFormat.Show();
            }
            else if (!int.TryParse(idTxt, out id))
            {
                ErrorWindow wrongFormat = new ErrorWindow("id must be a number");
                wrongFormat.Show();
            }
            else
            {
                ReservationController.cancel(id);
                populateRsvGd();
                populateRoomGd();
            }

        }

        private void CleaningReport_Click(object sender, RoutedEventArgs e)
        {
            string idTxt = searchRoomId.Text;
            int td;

            if(idTxt == "")
            {
                ErrorWindow r = new ErrorWindow("please fill necessary field(s)");
                r.Show();
            }
            else
            {
                if(!int.TryParse(idTxt, out td))
                {
                    ErrorWindow r = new ErrorWindow("id must be a number");
                    r.Show();
                }
                else
                {
                    Reservation r = ReservationController.getByCurrentRoom(td);
                    if( r == null)
                    {
                        ErrorWindow er = new ErrorWindow("room not found");
                        er.Show();
                    }
                    else
                    {
                        CleaningReport cr = new CleaningReport(r, this);
                        cr.Show();
                        populateRsvGd2();
                    }
                    
                }
            }
        }

        private void submitPurchase_Click(object sender, RoutedEventArgs e)
        {
            string detail = detailTxt.Text;
            detailTxt.Text = "";
            if(detail == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                RequestController.add(user, "Purchase", detail);
            }
            populatefundpurGd();
        }

        private void submitFund_Click(object sender, RoutedEventArgs e)
        {
            string detail = detailTxt.Text;
            detailTxt.Text = "";
            if (detail == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                RequestController.add(user, "Fund", detail);
            }
            populatefundpurGd();
        }



        private void accBtn_Click(object sender, RoutedEventArgs e)
        {
            string reqId = requestId.Text;
            string dcl = responseTxt.Text;
            int id;
            requestId.Text = "";
            responseTxt.Text = "";

            if(reqId == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if(!int.TryParse(reqId, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    Request req = RequestController.getByIdByType(id, "Fund");
                    if(req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        req.Status = "Accepted";
                        req.Response = dcl;
                        DbEntities.saves();
                        populateRequestGd(fundGd, "Fund");
                    }
                }
            }
        }

        private void dclBtn_Click(object sender, RoutedEventArgs e)
        {
            string reqId = requestId.Text;
            string dcl = responseTxt.Text;
            int id;
            requestId.Text = "";
            responseTxt.Text = "";

            if (reqId == "" || dcl == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(reqId, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    Request req = RequestController.getByIdByType(id, "Fund");
                    if (req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        req.Status = "Declined";
                        req.Response = dcl;
                        DbEntities.saves();
                        populateRequestGd(fundGd, "Fund");
                    }
                }
            }
        }

        private void cancelReqBtn_Click(object sender, RoutedEventArgs e)
        {
            string idtext = searchReqId.Text;
            int id;
            searchReqId.Text = "";

            if (idtext == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    Request req = RequestController.getByIdByEmp(id, user);
                    if (req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        if(req.Status != "Pending")
                        {
                            ErrorWindow er = new ErrorWindow("this request cannot be cancelled");
                            er.Show();
                        }
                        else
                        {
                            req.Status = "Completed";

                            DbEntities.saves();
                            populatefundpurGd();
                        }
                    }
                }
            }
        }

        private void accBtn2_Click(object sender, RoutedEventArgs e)
        {
            string reqId = requestId2.Text;
            string dcl = responseTxt2.Text;
            int id;
            requestId2.Text = "";
            responseTxt2.Text = "";

            if (reqId == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(reqId, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    Request req = RequestController.getByIdByType(id, "Purchase");
                    if (req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        req.Status = "Accepted";
                        req.Response = dcl;
                        DbEntities.saves();
                        populateRequestGd(purcGd, "Purchase");
                    }
                }
            }
        }

        private void dclBtn2_Click(object sender, RoutedEventArgs e)
        {
            string reqId = requestId2.Text;
            string dcl = responseTxt2.Text;
            int id;
            requestId2.Text = "";
            responseTxt2.Text = "";

            if (reqId == "" || dcl == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(reqId, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    Request req = RequestController.getByIdByType(id, "Purchase");
                    if (req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        req.Status = "Declined";
                        req.Response = dcl;
                        DbEntities.saves();
                        populateRequestGd(purcGd, "Purchase");
                    }
                }
            }
        }

        private void submitPurReport_Click(object sender, RoutedEventArgs e)
        {
            string priceText = purRepPrice.Text;
            string reqText = purRepReqId.Text;
            int price;
            int id;
            DateTime date;

            purRepPrice.Text = "";
            purRepReqId.Text = "";

            if (priceText == "" || reqText == "" || dateBought.SelectedDate == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                date = dateBought.SelectedDate.Value;
                dateBought.SelectedDate = null;
                if (!int.TryParse(priceText, out price))
                {
                    ErrorWindow er = new ErrorWindow("price must be a number");
                    er.Show();
                }
                else if(!int.TryParse(reqText, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    PurchaseReport rp = PurchaseReportController.getbyReqId(id);
                    Request req = RequestController.getToPurchase(id);
                    if(req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else if(rp != null)
                    {
                        ErrorWindow er = new ErrorWindow("a report for this request already exist");
                        er.Show();
                    }
                    else
                    {
                        PurchaseReportController.addReport(price, id, date, user);
                        populatePurRepGd();
                    }
                }
            }
        }

        private void purRepSearch_Click(object sender, RoutedEventArgs e)
        {
            string reqId = purRepId.Text;
            purRepId.Text = "";
            int id;

            if (reqId == "" )
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(reqId, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    PurchaseReport pr = PurchaseReportController.getbyId(id);
                    if (pr == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        EditPurchaseReport edit = new EditPurchaseReport(pr, this);
                        edit.Show();
                    }
                }
            }
        }

        private void editReqBtn_Click(object sender, RoutedEventArgs e)
        {
            string idtext = searchReqId.Text;
            int id;
            searchReqId.Text = "";

            if (idtext == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    Request req = RequestController.getByIdByEmp(id, user);
                    if (req == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        if (req.Status != "Pending")
                        {
                            ErrorWindow er = new ErrorWindow("this request cannot be edited");
                            er.Show();
                        }
                        else
                        {
                            EditRequest ed = new EditRequest(req, this);
                            ed.Show();
                            populatefundpurGd();
                        }
                    }
                }
            }
        }

        private void submitPlan_Click(object sender, RoutedEventArgs e)
        {
            string name = newAttractionName.Text;
            string details = planDetails.Text;
            string desc = planDesc.Text;


            if (name == "" || details == "" || desc == "" || cmbPlanType.SelectedValue == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                string type = cmbPlanType.SelectedValue.ToString();

                PlanSubmissionController.newSubmission(name, details, desc, type, "Add");

                newAttractionName.Text = "";
                planDetails.Text = "";
                planDesc.Text = "";
                cmbPlanType.SelectedIndex = -1;
            }
        }

        private void submissionSearch_Click(object sender, RoutedEventArgs e)
        {
            string idtext = submissionId.Text;
            int id;
            submissionId.Text = "";

            if (idtext == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    PlanSubmission ps = PlanSubmissionController.getById(id);
                    if (ps == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        if (ps.Status != "Pending")
                        {
                            ErrorWindow er = new ErrorWindow("this submission cannot be edited");
                            er.Show();
                        }
                        else
                        {
                            EditSubmission ed = new EditSubmission(ps, this);
                            ed.Show();
                        }
                    }
                }
            }
        }

        private void attrideSearch_Click(object sender, RoutedEventArgs e)
        {
            string idtext = attrideId.Text;
            int id;
            attrideId.Text = "";

            if (idtext == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    AttractionRide ar = AttractionRideController.getById(id);
                    if (ar == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        EditAttractionRide ed = new EditAttractionRide(ar, this);
                        ed.Show();
                        
                    }
                }
            }
        }

        private void addMt_Click(object sender, RoutedEventArgs e)
        {
            string idtext = rideId.Text;
            int id;
            rideId.Text = "";

            if (idtext == "" || mtDate.SelectedDate == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                DateTime mt = mtDate.SelectedDate.Value;
                mtDate.SelectedDate = null;
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    AttractionRide ar = AttractionRideController.getById(id);
                    if(ar.Type == "Attraction")
                    {
                        ar = null;
                    }

                    if (ar == null)
                    {
                        ErrorWindow er = new ErrorWindow("ride not found");
                        er.Show();
                    }
                    else
                    {
                        MaintenanceController.addSchedule(ar, mt);
                        populateMtGd();
                        populateReqMtGd();
                    }
                }
            }
        }

        private void editMt_Click(object sender, RoutedEventArgs e)
        {
            string idtext = mtId.Text;
            int id;
            mtId.Text = "";

            if (idtext == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    MaintenanceSchedule mtsched = MaintenanceController.getById(id);
                    if (mtsched == null)
                    {
                        ErrorWindow er = new ErrorWindow("schedule not found");
                        er.Show();
                    }
                    else
                    {
                        EditMaintenance ed = new EditMaintenance(mtsched, this);
                        ed.Show();
                        populateMtGd();
                        populateReqMtGd();
                    }
                }
            }
        }

        private void adMtrep_Click(object sender, RoutedEventArgs e)
        {
            string idtext = searchMtId.Text;
            string details = mtDetails.Text;
            int id;
            searchMtId.Text = "";
            mtDetails.Text = "";

            if (idtext == "" || details == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    MaintenanceSchedule mtsched = MaintenanceController.getById(id);
                    if (mtsched == null)
                    {
                        ErrorWindow er = new ErrorWindow("schedule not found");
                        er.Show();
                    }
                    else if (mtsched.Status != "Done")
                    {
                        ErrorWindow er = new ErrorWindow("maintenance not done yet");
                        er.Show();
                    }
                    else if (MaintenanceReportController.getByMt(mtsched) != null)
                    {
                        ErrorWindow er = new ErrorWindow("Maintenance report already exist");
                        er.Show();
                    }
                    else
                    {
                        MaintenanceReportController.addReport(mtsched, details);
                        populateMtGd();
                        populateReqMtGd();
                    }
                }
            }
        }

        private void editMtRep_Click(object sender, RoutedEventArgs e)
        {
            string idtext = mtRepId.Text;
            int id;
            mtRepId.Text = "";

            if (idtext == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    MaintenanceReport mtrep = MaintenanceReportController.getById(id);
                    if (mtrep == null)
                    {
                        ErrorWindow er = new ErrorWindow("report not found");
                        er.Show();
                    }
                    else
                    {
                        EditMtReport ed = new EditMtReport(mtrep, this);
                        ed.Show();
                        populateMtRepGd();
                        populateMtGd();
                        populateReqMtGd();
                    }
                }
            }
        }

        private void submitLeave_Click(object sender, RoutedEventArgs e)
        {
            string reason = leaveReason.Text;
            string dc = dayCount.Text;
            int daycount;

            leaveReason.Text = "";
            dayCount.Text = "";

            if(dc == "" || reason == "" || startDate.SelectedDate == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                DateTime sDate = startDate.SelectedDate.Value;

                startDate.SelectedDate = null;
                if (!int.TryParse(dc, out daycount))
                {
                    ErrorWindow er = new ErrorWindow("day count must be a number");
                    er.Show();
                }
                else if (LeaveRequestController.getAllByEmp(user).Count > 0)
                {
                    ErrorWindow er = new ErrorWindow("you already have a request on progress");
                    er.Show();
                }
                else
                {
                    LeaveRequestController.newRequest(user, sDate, daycount, reason);
                    populateLeaveGd();
                }
            }
        }

        private void editLeave_Click(object sender, RoutedEventArgs e)
        {
            if (LeaveRequestController.getAllByEmp(user).Count > 0)
            {
                LeaveRequest l = LeaveRequestController.getAllByEmp(user)[0];
                if(l.Status != "Pending")
                {
                    ErrorWindow er = new ErrorWindow("you can't edit this request");
                    er.Show();
                }
                else
                {
                    EditLeave ed = new EditLeave(l , this);
                    ed.Show();
                }
               
            }
            else
            {
                ErrorWindow er = new ErrorWindow("you have no request on progress");
                er.Show();
            }
        }

        private void submitResignation_Click(object sender, RoutedEventArgs e)
        {
            string reason = resignReason.Text;

            resignReason.Text = "";

            if (reason == "" || resignDate.SelectedDate == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                DateTime sDate = resignDate.SelectedDate.Value;

                resignDate.SelectedDate = null;

                if (ResignationRequestController.getAllByEmp(user).Count > 0)
                {
                    ErrorWindow er = new ErrorWindow("you already have a request on progress");
                    er.Show();
                }
                else if ((sDate - DateTime.Today).Days < 60)
                {
                    ErrorWindow er = new ErrorWindow("resignation must be atleast 2 months from today");
                    er.Show();
                }
                else
                {
                    ResignationRequestController.addRequest(user, reason, sDate);
                    populateResignationGd();
                }
            }
        }

        private void editResignation_Click(object sender, RoutedEventArgs e)
        {
            if (ResignationRequestController.getAllByEmp(user).Count > 0)
            {
                ResignationRequest l = ResignationRequestController.getAllByEmp(user)[0];
                if (l.Status != "Pending")
                {
                    ErrorWindow er = new ErrorWindow("you can't edit this request");
                    er.Show();
                }
                else
                {
                    EditResign ed = new EditResign(l, this);
                    ed.Show();
                }

            }
            else
            {
                ErrorWindow er = new ErrorWindow("you have no request on progress");
                er.Show();
            }
        }

        private void accBtnLeave_Click(object sender, RoutedEventArgs e)
        {
            string idtext = searchLeaveReq.Text;
            int id;
            searchLeaveReq.Text = "";

            if (idtext == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    LeaveRequest l = LeaveRequestController.getById(id);
                    if (l == null)
                    {
                        ErrorWindow er = new ErrorWindow("report not found");
                        er.Show();
                    }
                    else
                    {
                        l.Status = "Accepted";
                        DbEntities.saves();
                        populatehrLeaveGd();
                    }
                }
            }
        }

        private void dclBtnLeave_Click(object sender, RoutedEventArgs e)
        {
            string idtext = searchLeaveReq.Text;
            string response = leaveResponse.Text; 
            int id;
            searchLeaveReq.Text = "";
            searchLeaveReq.Text = "";

            if (idtext == "" || response == "")
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    LeaveRequest l = LeaveRequestController.getById(id);
                    if (l == null)
                    {
                        ErrorWindow er = new ErrorWindow("report not found");
                        er.Show();
                    }
                    else
                    {
                        l.Status = "Declined";
                        l.Response = response;
                        DbEntities.saves();
                        populatehrLeaveGd();
                    }
                }
            }
        }

        private void submissionSearch2_Click(object sender, RoutedEventArgs e)
        {
            string idtext = submissionId2.Text;
            int id;
            submissionId2.Text = "";

            if (idtext == null || cmbStatus.SelectedValue == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                string status = cmbStatus.SelectedValue.ToString();
                if (!int.TryParse(idtext, out id))
                {
                    ErrorWindow er = new ErrorWindow("id must be a number");
                    er.Show();
                }
                else
                {
                    PlanSubmission ps = PlanSubmissionController.getById(id);
                    if (ps == null)
                    {
                        ErrorWindow er = new ErrorWindow("id not found");
                        er.Show();
                    }
                    else
                    {
                        if (ps.Status != "Waiting for Construction")
                        {
                            ErrorWindow er = new ErrorWindow("this submission cannot be edited");
                            er.Show();
                        }
                        else
                        {
                            ps.Status = status;
                            if(status == "Complete")
                            {
                                status = "Available";
                            }
                            AttractionRideController.getById((int)ps.AttractionRideId).Status = status;
                            DbEntities.saves();
                        }
                    }
                }
            }
        }
    }
}
