﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for Dashboard.xaml
    /// </summary>
    /// 

    public partial class Dashboard : Window
    {
        public Employee user;

        public Dashboard()
        {
            LoginPage login = new LoginPage();
            this.Close();
            login.Show();
        }
        public Dashboard(Employee user)
        {
            InitializeComponent();
            this.user = user;
            empNameText.Text += user.Name;
            empDivText.Text = user.Department;

            Style st = FindResource("setVisible") as Style;
            if (user.Department == "Attraction Department")
            {
                Attraction.Style = st;
            }
            else if(user.Department == "Human Resource Department")
            {
                Hrd.Style = st;
            }
            else if(user.Department == "Manager")
            {
                Manager.Style = st;
            }
        }

        private void logoutButton_Click(object sender, RoutedEventArgs e)
        {
            this.user = null;
            LoginPage login = new LoginPage();
            this.Close();
            login.Show();
        }

        private void newEmpButton_Click(object sender, RoutedEventArgs e)
        {
            newEmployee regEmp = new newEmployee();
            regEmp.Show();
        }

        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            String name = searchBox.Text;
            if(name != "")
            {
                Employee empFound = EmployeeController.getByName(name);
                if(empFound == null)
                {
                    ErrorWindow notFound = new ErrorWindow("Employee not found");
                    notFound.Show();
                }
                else
                {
                    EmployeeInfo found = new EmployeeInfo(empFound);
                    found.Show();
                }
            }
        }

        private void genBtn_Click(object sender, RoutedEventArgs e)
        {
            Ticket newTicket = TicketController.newTicket();
            qrCodeImg.Source = TicketController.generateQr(newTicket);
            tickId.Text = newTicket.TicketId;
        }

        private void valBtn_Click(object sender, RoutedEventArgs e)
        {
            String ticketId = inputIdTxt.Text;
            inputIdTxt.Text = "";
            int isValidated = TicketController.validateTicket(ticketId);
            if(isValidated == -1)
            {
                errorMsg.Text = "Ticket is Out of Date";
            }
            else if(isValidated == 1)
            {
                errorMsg.Text = "Ticket Invalid";
            }
            else if(isValidated == 2)
            {
                errorMsg.Text = "Ticket Already Activated";
            }
            else 
            {
                errorMsg.Text = "Ticket Validated";
            }
        }
    }
}
