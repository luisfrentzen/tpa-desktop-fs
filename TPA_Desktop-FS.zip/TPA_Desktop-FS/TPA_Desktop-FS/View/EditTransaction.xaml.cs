﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditTransaction.xaml
    /// </summary>
    public partial class EditTransaction : Window
    {
        Transaction toEdit;
        Dashboard dbWindow;
        public EditTransaction(Transaction edit, Dashboard window)
        {
            InitializeComponent();
            toEdit = edit;
            dbWindow = window;
            amountDetail.Text = edit.TrAmount.ToString();
            trTypeText.Text = edit.TrType;
            trDateText.Text = edit.TrDate.ToString();
        }

        private void trUpdate_Click(object sender, RoutedEventArgs e)
        {
            int trId = toEdit.TrId;
            string trAmountText = amountDetail.Text;
            amountDetail.Text = "";
            int amount;

            if(trAmountText == "")
            {
                errorMsg.Text = "please fill the necessary field(s)";
            }
            else
            {
                if (!int.TryParse(trAmountText, out amount))
                {
                    errorMsg.Text = "amount must be number";
                }
                else
                {
                    TransactionController.updateTransaction(trId, amount);
                    errorMsg.Text = "transaction updated";
                }
            }
            
        }

        private void trDelete_Click(object sender, RoutedEventArgs e)
        {
            TransactionController.deleteTransaction(toEdit);
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            dbWindow.populateTrGd(toEdit.TrType);
        }
    }
}
