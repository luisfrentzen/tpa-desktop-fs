﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditLeave.xaml
    /// </summary>
    public partial class EditLeave : Window
    {
        LeaveRequest l;
        Dashboard db;
        public EditLeave(LeaveRequest le, Dashboard dbwindow)
        {
            InitializeComponent();
            l = le;
            db = dbwindow;

            startDate.SelectedDate = l.StartDate.Value;
            leaveReason.Text = l.Details;
            dayCount.Text = l.DayCount.ToString();
        }

        private void udpdateLeave_Click(object sender, RoutedEventArgs e)
        {
            string reason = leaveReason.Text;
            string dc = dayCount.Text;
            int daycount;

            leaveReason.Text = "";
            dayCount.Text = "";

            if (dc == "" || reason == "" || startDate.SelectedDate == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                DateTime sDate = startDate.SelectedDate.Value;

                startDate.SelectedDate = null;
                if (!int.TryParse(dc, out daycount))
                {
                    ErrorWindow er = new ErrorWindow("day count must be a number");
                    er.Show();
                }
                else
                {
                    l.DayCount = daycount;
                    l.Details = reason;
                    l.StartDate = sDate;

                    DbEntities.saves();
                    this.Close();
                }
            }
        }

        private void cancelLeave_Click(object sender, RoutedEventArgs e)
        {
            l.Status = "Completed";

            DbEntities.saves();
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            db.populateLeaveGd();
        }
    }
}
