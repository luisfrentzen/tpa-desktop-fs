﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for Checkout.xaml
    /// </summary>
    public partial class Checkout : Window
    {
        Reservation r;
        Dashboard dbWindow;
        public Checkout(Reservation reservation, Dashboard db)
        {
            InitializeComponent();
            r = reservation;
            dbWindow = db;

            populateChargesGd();
            room.Text = ((int)r.RoomId).ToString();
        }

        private void populateChargesGd()
        {
            List<RoomCharge> data = RoomChargesController.getAllByRsv(r.Id);
            dgCharges.IsReadOnly = true;
            dgCharges.CanUserResizeColumns = false;
            dgCharges.CanUserResizeRows = false;
            dgCharges.CanUserSortColumns = false;
            dgCharges.CanUserDeleteRows = false;
            dgCharges.CanUserAddRows = false;
            dgCharges.ItemsSource = data;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            r.Status = "Completed";
            dbWindow.populateRsvGd();
            dbWindow.populateRoomGd();
            DbEntities.saves();
        }

        private void doneBtn_Click(object sender, RoutedEventArgs e)
        {
            List<RoomCharge> data = RoomChargesController.getAllByRsv(r.Id);
            int total;

            if (data.Any())
            {
                total = RoomChargesController.getTotal(r.Id);
                
            }
            else
            {
                total = 0;
            }

            RoomChargesController.completeAllById(data);

            PaymentWindow p = new PaymentWindow(total, this, "Hotel");
            p.Show();

        }
    }
}
