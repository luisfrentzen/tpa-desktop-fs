﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for ViewFeedback.xaml
    /// </summary>
    public partial class ViewFeedback : Window
    {
        public ViewFeedback(string dept)
        {
            InitializeComponent();
            populateFbGd(dept);
        }

        private void populateFbGd(string dept)
        {
            List<Feedback> data = FeedbackController.getAllByDept(dept);
            dgFeedback.IsReadOnly = true;
            dgFeedback.CanUserResizeColumns = false;
            dgFeedback.CanUserResizeRows = false;
            dgFeedback.CanUserSortColumns = false;
            dgFeedback.CanUserDeleteRows = false;
            dgFeedback.CanUserAddRows = false;
            dgFeedback.ItemsSource = data;
        }
    }
}
