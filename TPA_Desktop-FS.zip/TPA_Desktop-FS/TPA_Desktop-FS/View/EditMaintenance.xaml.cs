﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditMaintenance.xaml
    /// </summary>
    public partial class EditMaintenance : Window
    {
        MaintenanceSchedule mt;
        Dashboard db;
        public EditMaintenance(MaintenanceSchedule m, Dashboard d)
        {
            InitializeComponent();
            mt = m;
            db = d;

            rideId.Text = mt.AttractionRideId.ToString();
            rideId.IsEnabled = false;
            mtDate.SelectedDate = mt.Time;

            if (m.Status == "Upcoming")
            {
                cmbStatus.SelectedIndex = 0;
            }
            else if(m.Status == "On Progress")
            {
                cmbStatus.SelectedIndex = 1;
            }
            else if(m.Status == "Done")
            {
                cmbStatus.SelectedIndex = 2;
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if(mt.Status == "On Progress")
            {
                AttractionRide ar = AttractionRideController.getById((int)mt.AttractionRideId);
                ar.Status = "On Maintenance";
                
            }
            else if(mt.Status == "Done" || mt.Status == "Completed")
            {
                AttractionRide ar = AttractionRideController.getById((int)mt.AttractionRideId);
                ar.Status = "Available";
            }
    
            DbEntities.saves();

            db.populateMtGd();
            db.populateOrdGd();
        }

        private void delMt_Click(object sender, RoutedEventArgs e)
        {
            mt.Status = "Completed";
            DbEntities.saves();
            this.Close();
        }

        private void addMt_Click(object sender, RoutedEventArgs e)
        {
            mt.Time = mtDate.SelectedDate.Value;
            mt.Status = cmbStatus.SelectedValue.ToString();
            DbEntities.saves();
            this.Close();

        }
    }
}
