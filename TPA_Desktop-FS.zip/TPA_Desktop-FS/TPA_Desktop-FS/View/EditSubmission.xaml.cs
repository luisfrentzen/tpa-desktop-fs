﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for EditSubmission.xaml
    /// </summary>
    public partial class EditSubmission : Window
    {
        PlanSubmission p;
        Dashboard d;
        public EditSubmission(PlanSubmission ps, Dashboard db)
        {
            InitializeComponent();
            p = ps;
            d = db;

            newAttractionName.Text = p.Name;
            planDesc.Text = p.Description;
            planDetails.Text = p.PlanDetails;
            subtype.Text = p.SubmissionType;

            if(p.Type == "Attraction")
            {
                cmbPlanType.SelectedIndex = 1;
            }
            else
            {
                cmbPlanType.SelectedIndex = 0;
            }

            cmbPlanType.IsEnabled = false;
        }

        private void done_Click(object sender, RoutedEventArgs e)
        {
            string name = newAttractionName.Text;
            string details = planDetails.Text;
            string desc = planDesc.Text;


            if (name == "" || details == "" || desc == "" || cmbPlanType.SelectedValue == null)
            {
                ErrorWindow er = new ErrorWindow("please fill the necessary field(s)");
                er.Show();
            }
            else
            {
                string type = cmbPlanType.SelectedValue.ToString();

                p.Type = type;
                p.Name = name;
                p.Description = desc;
                p.PlanDetails = details;

                DbEntities.saves();
                errorMsg.Text = "submission updated";
            }
        }

        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            p.Status = "Completed";
            DbEntities.saves();
            this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            d.populateSubmissionGd();
        }
    }
}
