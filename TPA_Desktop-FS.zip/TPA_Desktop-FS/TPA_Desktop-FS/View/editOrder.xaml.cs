﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for editOrder.xaml
    /// </summary>
    public partial class editOrder : Window
    {
        Order toEdit;
        TableInfo tbWindow;
        public editOrder(Order edit, TableInfo tb)
        {
            InitializeComponent();
            toEdit = edit;
            tbWindow = tb;
            qtyTxt.Text = toEdit.Qty.ToString();
            priceTxt.Text = toEdit.Price.ToString();
            menuTxt.Text = toEdit.MenuName;
            tableTxt.Text = toEdit.TableId.ToString();

            if(toEdit.OrderType == "Dine In")
            {
                cmbOrdType.SelectedIndex = 0;
            }
            else
            {
                cmbOrdType.SelectedIndex = 1;
                cmbOrdType.IsEnabled = false;
            }

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            tbWindow.populateTableOrderGd();
        }

        private void ordDelete_Click(object sender, RoutedEventArgs e)
        {
            OrderController.deleteOrder(toEdit);
            this.Close();
        }

        private void ordUpdate_Click(object sender, RoutedEventArgs e)
        {
            int qty;
            int price;
            if(qtyTxt.Text == "" || priceTxt.Text == "" || cmbOrdType.SelectedValue == null)
            {
                errorMsg.Text = "please fill necessary field(s)";
            }
            else
            {
                if(!int.TryParse(qtyTxt.Text, out qty))
                {
                    errorMsg.Text = "item quantity must be a number";
                }
                else if(!int.TryParse(priceTxt.Text, out price))
                {
                    errorMsg.Text = "item price must be a number";
                }
                else
                {
                    toEdit.Price = price;
                    toEdit.Qty = qty;
                    toEdit.OrderType = cmbOrdType.SelectedValue.ToString();

                    OrderController.updateOrder(toEdit);
                    errorMsg.Text = "order updated";
                }
            }
        }
    }
}
