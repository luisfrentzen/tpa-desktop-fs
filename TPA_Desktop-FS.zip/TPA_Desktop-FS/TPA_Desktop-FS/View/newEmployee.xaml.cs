﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TPA_Desktop_FS.Class;

namespace TPA_Desktop_FS.View
{
    /// <summary>
    /// Interaction logic for newEmployee.xaml
    /// </summary>
    public partial class newEmployee : Window
    {
        public newEmployee()
        {
            InitializeComponent();
        }

        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            String name = nameTxt.Text;
            String uname = unameTxt.Text;
            String pwd = pwdTxt.Text;
            String salary = salaryTxt.Text;
            
            int empSalary;
            Boolean isSalValid = int.TryParse(salary, out empSalary);

            if(name == "" || uname == "" || pwd == "" || salary == "" || cmbDept.SelectedValue == null)
            {
                errorTxt.Text = "Please fill the necessary field(s)";
            }
            else if(isSalValid == false)
            {
                errorTxt.Text = "Salary must be a valid number";
            }
            else
            {
                String dept = cmbDept.SelectedValue.ToString();
                EmployeeController.newEmployee(name, uname, pwd, dept, empSalary);
                this.Close();
            }
            
        }

        private void cancelBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
